#!/usr/bin/env python3
"""
lookup_sku.py - Queries MMLTSLIB.INVMST on AS400 (via mms_as400 ODBC) for item description (IDESCR)
"""
import sys
import json
import os

def main():
    if len(sys.argv) < 2:
        print(json.dumps({"status": "error", "message": "Usage: lookup_sku.py <sku> [dsn_name] [username] [password] [library]"}))
        sys.exit(1)

    sku = sys.argv[1].strip()
    if not sku:
        print(json.dumps({"status": "error", "message": "SKU cannot be empty."}))
        sys.exit(1)

    dsn_name = sys.argv[2].strip() if len(sys.argv) > 2 and sys.argv[2].strip() else "mms_as400"
    username = sys.argv[3].strip() if len(sys.argv) > 3 and sys.argv[3].strip() else ""
    password = sys.argv[4].strip() if len(sys.argv) > 4 and sys.argv[4].strip() else ""
    library  = sys.argv[5].strip() if len(sys.argv) > 5 and sys.argv[5].strip() else "MMLTSLIB"

    # If username/password not passed in args, check as400_config.json
    script_dir = os.path.dirname(os.path.abspath(__file__))
    app_dir = os.path.abspath(os.path.join(script_dir, ".."))
    config_file = os.path.join(app_dir, "as400_config.json")
    if os.path.exists(config_file):
        try:
            with open(config_file, "r", encoding="utf-8") as f:
                cfg = json.load(f)
                if not username and cfg.get("username"):
                    username = cfg.get("username", "")
                if not password and cfg.get("password"):
                    password = cfg.get("password", "")
                if not dsn_name or dsn_name == "mms_as400":
                    dsn_name = cfg.get("dsn_name", "mms_as400")
                if not library or library == "MMLTSLIB":
                    library = cfg.get("library", "MMLTSLIB")
        except Exception:
            pass

    try:
        import pyodbc
    except ImportError:
        print(json.dumps({"status": "error", "message": "pyodbc module not found in Python environment."}))
        sys.exit(1)

    conn_str = f"DSN={dsn_name}"
    if username:
        conn_str += f";UID={username}"
    if password:
        conn_str += f";PWD={password}"

    try:
        conn = pyodbc.connect(conn_str, autocommit=True)
        cursor = conn.cursor()
    except Exception as e:
        print(json.dumps({
            "status": "error",
            "message": f"Connection failed to AS400 DSN '{dsn_name}': {str(e)}"
        }))
        sys.exit(1)

    try:
        # Table is library.INVMST (e.g. MMLTSLIB.INVMST)
        table_name = f"{library}.INVMST"
        
        # Prepare queries to search by INUMBR (numeric or char), IUPC, or IBCD
        found = False
        desc = ""
        price = 0.0

        # Try numeric lookup first if digits
        if sku.isdigit():
            sku_num = int(sku)
            try:
                cursor.execute(f"SELECT IDESCR FROM {table_name} WHERE INUMBR = ? FETCH FIRST 1 ROWS ONLY", (sku_num,))
                row = cursor.fetchone()
                if row and row[0]:
                    desc = str(row[0]).strip()
                    found = True
            except Exception:
                pass

        # Try string / barcode / UPC lookup
        if not found:
            try:
                cursor.execute(f"SELECT IDESCR FROM {table_name} WHERE TRIM(CHAR(INUMBR)) = ? FETCH FIRST 1 ROWS ONLY", (sku,))
                row = cursor.fetchone()
                if row and row[0]:
                    desc = str(row[0]).strip()
                    found = True
            except Exception:
                pass

        # Fallback: check UPC table or general column scan in INVMST
        if not found:
            try:
                # Some MMS databases have IUPC or IVNDR in INVMST
                cursor.execute(f"SELECT IDESCR FROM {table_name} WHERE IUPC = ? OR IVNDR = ? FETCH FIRST 1 ROWS ONLY", (sku, sku))
                row = cursor.fetchone()
                if row and row[0]:
                    desc = str(row[0]).strip()
                    found = True
            except Exception:
                pass

        conn.close()

        if found:
            print(json.dumps({
                "status": "success",
                "found": True,
                "sku": sku,
                "description": desc,
                "price": price
            }))
        else:
            print(json.dumps({
                "status": "success",
                "found": False,
                "sku": sku,
                "message": f"SKU '{sku}' not found in {table_name}."
            }))

    except Exception as e:
        print(json.dumps({
            "status": "error",
            "message": f"Query error on {table_name}: {str(e)}"
        }))

if __name__ == "__main__":
    main()
