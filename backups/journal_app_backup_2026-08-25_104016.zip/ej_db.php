<?php
// ej_db.php - Dedicated SQLite connection and helper functions for Electronic Journal (EJ)
require_once __DIR__ . '/db.php'; // Gives access to Master tables (Store, Register, Tender)

$ejDbFile = __DIR__ . '/ej.db';

try {
    $ejPdo = new PDO('sqlite:' . $ejDbFile);
    $ejPdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Create ej_entries table if it doesn't exist yet
    $ejPdo->exec("
        CREATE TABLE IF NOT EXISTS ej_entries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            entry_date TEXT NOT NULL DEFAULT '',
            entry_time TEXT NOT NULL DEFAULT '',
            store_code TEXT NOT NULL DEFAULT '',
            register_number TEXT NOT NULL DEFAULT '',
            transaction_number TEXT NOT NULL DEFAULT '',
            invoice_number TEXT NOT NULL DEFAULT '',
            member_number TEXT NOT NULL DEFAULT '',
            customer_name TEXT NOT NULL DEFAULT '',
            sales_associate TEXT NOT NULL DEFAULT '',
            associate_id TEXT NOT NULL DEFAULT '',
            till_number TEXT NOT NULL DEFAULT '',
            items TEXT NOT NULL DEFAULT '[]',
            tenders TEXT NOT NULL DEFAULT '[]',
            subtotal REAL NOT NULL DEFAULT 0.0,
            vatable_sales REAL NOT NULL DEFAULT 0.0,
            vat_rate REAL NOT NULL DEFAULT 12.0,
            total_vat REAL NOT NULL DEFAULT 0.0,
            total_non_vat REAL NOT NULL DEFAULT 0.0,
            total_amount REAL NOT NULL DEFAULT 0.0,
            created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
            updated_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
        )
    ");

    // Dynamically add missing columns (for existing databases)
    $cols = $ejPdo->query("PRAGMA table_info(ej_entries)")->fetchAll(PDO::FETCH_ASSOC);
    $colNames = array_column($cols, 'name');
    if (!in_array('vatable_sales', $colNames)) {
        $ejPdo->exec("ALTER TABLE ej_entries ADD COLUMN vatable_sales REAL NOT NULL DEFAULT 0.0");
    }
    if (!in_array('vat_rate', $colNames)) {
        $ejPdo->exec("ALTER TABLE ej_entries ADD COLUMN vat_rate REAL NOT NULL DEFAULT 12.0");
    }

    // Indexes for speed
    $ejPdo->exec("CREATE INDEX IF NOT EXISTS idx_ej_date ON ej_entries(entry_date)");
    $ejPdo->exec("CREATE INDEX IF NOT EXISTS idx_ej_store_reg ON ej_entries(store_code, register_number)");
    $ejPdo->exec("CREATE INDEX IF NOT EXISTS idx_ej_invoice ON ej_entries(invoice_number)");
    $ejPdo->exec("CREATE INDEX IF NOT EXISTS idx_ej_trx ON ej_entries(transaction_number)");

} catch (PDOException $e) {
    die('EJ Database connection failed: ' . htmlspecialchars($e->getMessage()));
}

/**
 * Loads the EJ print layout configuration from ej_print_layout.json
 */
function getEjPrintLayout() {
    $configFile = __DIR__ . '/ej_print_layout.json';
    if (!file_exists($configFile)) {
        return [
            [['key' => '_custom_1', 'label' => '=========================================', 'flex' => 1, 'align' => 'center', 'margin_left' => 0, 'margin_right' => 0, 'font_size' => 13]],
            [['key' => '_custom_2', 'label' => 'ELECTRONIC JOURNAL RECEIPT', 'flex' => 1, 'align' => 'center', 'margin_left' => 0, 'margin_right' => 0, 'font_size' => 13]],
            [['key' => 'store_code', 'label' => 'Store:', 'flex' => 1, 'align' => 'left'], ['key' => 'register_number', 'label' => 'Reg:', 'flex' => 1, 'align' => 'right']],
            [['key' => 'invoice_number', 'label' => 'Invoice #:', 'flex' => 1, 'align' => 'left'], ['key' => 'transaction_number', 'label' => 'Trx #:', 'flex' => 1, 'align' => 'right']],
            [['key' => 'entry_date', 'label' => 'Date:', 'flex' => 1, 'align' => 'left'], ['key' => 'entry_time', 'label' => 'Time:', 'flex' => 1, 'align' => 'right']],
            [['key' => 'member_number', 'label' => 'Member #:', 'flex' => 1, 'align' => 'left'], ['key' => 'customer_name', 'label' => 'Name:', 'flex' => 1, 'align' => 'right']],
            [['key' => 'till_number', 'label' => 'Till #:', 'flex' => 1, 'align' => 'left'], ['key' => 'sales_associate', 'label' => 'Cashier:', 'flex' => 1, 'align' => 'right']],
            [['key' => '_custom_3', 'label' => '-----------------------------------------', 'flex' => 1, 'align' => 'center']],
            [['key' => 'items_list', 'label' => 'Items Breakdown', 'flex' => 1, 'align' => 'left']],
            [['key' => '_custom_4', 'label' => '-----------------------------------------', 'flex' => 1, 'align' => 'center']],
            [['key' => 'subtotal', 'label' => 'Subtotal:', 'flex' => 1, 'align' => 'left', 'margin_left' => 5, 'margin_right' => 7]],
            [['key' => 'total_vat', 'label' => 'Total VAT:', 'flex' => 1, 'align' => 'left', 'margin_left' => 5, 'margin_right' => 7]],
            [['key' => 'total_non_vat', 'label' => 'Total Non-VAT:', 'flex' => 1, 'align' => 'left', 'margin_left' => 5, 'margin_right' => 7]],
            [['key' => 'total_amount', 'label' => 'TOTAL AMOUNT:', 'flex' => 1, 'align' => 'left', 'margin_left' => 5, 'margin_right' => 7, 'font_size' => 13]],
            [['key' => '_custom_5', 'label' => '-----------------------------------------', 'flex' => 1, 'align' => 'center']],
            [['key' => 'tenders_list', 'label' => 'Payment Tender Breakdown', 'flex' => 1, 'align' => 'left']],
            [['key' => '_custom_6', 'label' => '=========================================', 'flex' => 1, 'align' => 'center', 'font_size' => 13]],
            [['key' => 'associate_id', 'label' => 'Associate ID:', 'flex' => 1, 'align' => 'left']],
            [['key' => '_custom_7', 'label' => 'THANK YOU FOR SHOPPING!', 'flex' => 1, 'align' => 'center']]
        ];
    }
    $json = file_get_contents($configFile);
    $data = json_decode($json, true);
    return is_array($data) ? $data : [];
}

/**
 * Saves EJ print layout configuration to ej_print_layout.json
 */
function saveEjPrintLayout($layout) {
    $configFile = __DIR__ . '/ej_print_layout.json';
    return file_put_contents($configFile, json_encode($layout, JSON_PRETTY_PRINT));
}

/**
 * Loads EJ print settings from ej_print_settings.json
 */
function getEjPrintSettings() {
    $file = __DIR__ . '/ej_print_settings.json';
    $defaults = [
        'paper_size'               => 'a4',
        'sheet_margin'             => 0.30,
        'top_title_margin_top'     => 25,
        'top_title_font_size'      => 16,
        'meta_gap'                 => 65,
        'meta_font_size'           => 14,
        'char_width'               => 54,
        'font_size'                => 15,
        'line_height'              => 1.36,
        'receipt_padding_x'        => 20,
        'receipt_padding_y'        => 6,
        'watermark_text'           => 'Electronic Journal Copy',
        'watermark_font_size'      => 60,
        'watermark_top'            => 75,
        'watermark_left'           => 50,
        'watermark_opacity'        => 0.16,
        'watermark_letter_spacing' => 3,

        // Granular Column & Variable Offsets
        'col_sku_width'            => 16,
        'col_desc_gap'             => 3,
        'col_price_width'          => 16,
        'col_qty_width'            => 6,
        'col_amt_width'            => 20,

        'col_subtotal_label'       => 28,
        'col_subtotal_amt'         => 20,
        'col_tax_label'            => 22,
        'col_tax_amt'              => 26,
        'col_total_label'          => 24,
        'col_total_amt'            => 24,
        'col_tender_label'         => 23,
        'col_tender_amt'           => 25,
        'col_change_label'         => 25,
        'col_change_amt'           => 18,

        'col_bir_vat_amt'          => 20,
        'col_vatable_amt'          => 22,
        'col_vat_amt'              => 22,
        'col_nonvat_amt'           => 18
    ];
    if (!file_exists($file)) {
        return $defaults;
    }
    $json = file_get_contents($file);
    $data = json_decode($json, true);
    return is_array($data) ? array_merge($defaults, $data) : $defaults;
}

/**
 * Saves EJ print settings to ej_print_settings.json
 */
function saveEjPrintSettings($settings) {
    $file = __DIR__ . '/ej_print_settings.json';
    return file_put_contents($file, json_encode($settings, JSON_PRETTY_PRINT));
}

/**
 * Fetch EJ entry by ID
 */
function getEjEntryById($id) {
    global $ejPdo;
    $stmt = $ejPdo->prepare("SELECT * FROM ej_entries WHERE id = :id");
    $stmt->execute([':id' => (int)$id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

/**
 * Build WHERE SQL & params for EJ entries filtering
 */
function buildEjFilterQuery($search = '', $store = '', $reg = '', $from = '', $to = '') {
    $clauses = [];
    $params = [];

    if ($search !== '') {
        $clauses[] = "(store_code LIKE :q OR register_number LIKE :q OR invoice_number LIKE :q OR transaction_number LIKE :q OR member_number LIKE :q OR customer_name LIKE :q OR sales_associate LIKE :q OR associate_id LIKE :q OR items LIKE :q)";
        $params[':q'] = '%' . $search . '%';
    }
    if ($store !== '') {
        $clauses[] = "store_code = :store";
        $params[':store'] = $store;
    }
    if ($reg !== '') {
        $clauses[] = "register_number = :reg";
        $params[':reg'] = $reg;
    }
    if ($from !== '' && $to !== '') {
        $clauses[] = "entry_date BETWEEN :from AND :to";
        $params[':from'] = $from;
        $params[':to'] = $to;
    } elseif ($from !== '') {
        $clauses[] = "entry_date >= :from";
        $params[':from'] = $from;
    } elseif ($to !== '') {
        $clauses[] = "entry_date <= :to";
        $params[':to'] = $to;
    }

    $whereSql = !empty($clauses) ? "WHERE " . implode(" AND ", $clauses) : "";
    return ['sql' => $whereSql, 'params' => $params];
}

/**
 * Count total matching EJ entries
 */
function countEjEntries($search = '', $store = '', $reg = '', $from = '', $to = '') {
    global $ejPdo;
    $filter = buildEjFilterQuery($search, $store, $reg, $from, $to);
    $stmt = $ejPdo->prepare("SELECT COUNT(*) FROM ej_entries {$filter['sql']}");
    $stmt->execute($filter['params']);
    return (int)$stmt->fetchColumn();
}

/**
 * Get paginated EJ entries
 */
function getEjEntries($search = '', $store = '', $reg = '', $from = '', $to = '', $limit = 50, $offset = 0) {
    global $ejPdo;
    $filter = buildEjFilterQuery($search, $store, $reg, $from, $to);
    $sql = "SELECT * FROM ej_entries {$filter['sql']} ORDER BY entry_date DESC, id DESC LIMIT :limit OFFSET :offset";
    $stmt = $ejPdo->prepare($sql);
    foreach ($filter['params'] as $k => $v) {
        $stmt->bindValue($k, $v, PDO::PARAM_STR);
    }
    $stmt->bindValue(':limit', (int)$limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', (int)$offset, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * Get list of unique register numbers in ej_entries for filter dropdown
 */
function getUniqueEjRegisters() {
    global $ejPdo;
    $stmt = $ejPdo->query("SELECT DISTINCT register_number FROM ej_entries WHERE register_number != '' ORDER BY register_number ASC");
    return $stmt->fetchAll(PDO::FETCH_COLUMN);
}

/**
 * Delete a single EJ entry by ID
 */
function deleteEjEntry($id) {
    global $ejPdo;
    $stmt = $ejPdo->prepare("DELETE FROM ej_entries WHERE id = :id");
    return $stmt->execute([':id' => (int)$id]);
}

/**
 * Delete all EJ entries
 */
function deleteAllEjEntries() {
    global $ejPdo;
    return $ejPdo->exec("DELETE FROM ej_entries");
}
