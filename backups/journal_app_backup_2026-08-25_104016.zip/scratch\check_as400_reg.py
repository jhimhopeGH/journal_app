import winreg

dsn_name = "mms_as400"
paths = [
    f"SOFTWARE\\ODBC\\ODBC.INI\\{dsn_name}",
    f"SOFTWARE\\WOW6432Node\\ODBC\\ODBC.INI\\{dsn_name}"
]

for p in paths:
    for root in [winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER]:
        try:
            with winreg.OpenKey(root, p) as key:
                print(f"=== Found key at {root} -> {p} ===")
                i = 0
                while True:
                    try:
                        name, val, typ = winreg.EnumValue(key, i)
                        print(f"  {name} = {val}")
                        i += 1
                    except OSError:
                        break
        except Exception:
            pass
