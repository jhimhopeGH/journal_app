#!/usr/bin/env python3
"""
import_as400.py - Imports Electronic Journal transactions from IBM AS400 / MMS ODBC DSN (mms_as400) into ej.db
"""
import sys
import os
import json
import sqlite3
import datetime

def main():
    if len(sys.argv) < 2:
        print(json.dumps({
            "status": "error",
            "message": "Usage: import_as400.py <store_code> [dsn_name] [username] [password] [date_from] [date_to] [db_file]"
        }))
        sys.exit(1)

    store_code = sys.argv[1].strip()
    dsn_name = sys.argv[2].strip() if len(sys.argv) > 2 and sys.argv[2].strip() else "mms_as400"
    username = sys.argv[3].strip() if len(sys.argv) > 3 and sys.argv[3].strip() else ""
    password = sys.argv[4].strip() if len(sys.argv) > 4 and sys.argv[4].strip() else ""
    date_from = sys.argv[5].strip() if len(sys.argv) > 5 and sys.argv[5].strip() else ""
    date_to = sys.argv[6].strip() if len(sys.argv) > 6 and sys.argv[6].strip() else ""
    
    script_dir = os.path.dirname(os.path.abspath(__file__))
    app_dir = os.path.abspath(os.path.join(script_dir, ".."))
    db_file = sys.argv[7].strip() if len(sys.argv) > 7 and sys.argv[7].strip() else os.path.join(app_dir, "ej.db")

    # Connect to local SQLite ej.db
    try:
        sqlite_conn = sqlite3.connect(db_file)
        sqlite_cur = sqlite_conn.cursor()
        
        # Ensure ej_entries table exists
        sqlite_cur.execute("""
            CREATE TABLE IF NOT EXISTS ej_entries (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                entry_date TEXT NOT NULL DEFAULT '',
                entry_time TEXT NOT NULL DEFAULT '',
                store_code TEXT NOT NULL DEFAULT '',
                register_number TEXT NOT NULL DEFAULT '',
                transaction_number TEXT NOT NULL DEFAULT '',
                invoice_number TEXT NOT NULL DEFAULT '',
                member_number TEXT NOT NULL DEFAULT '',
                customer_name TEXT NOT NULL DEFAULT '',
                sales_associate TEXT NOT NULL DEFAULT '',
                associate_id TEXT NOT NULL DEFAULT '',
                till_number TEXT NOT NULL DEFAULT '',
                items TEXT NOT NULL DEFAULT '[]',
                tenders TEXT NOT NULL DEFAULT '[]',
                subtotal REAL NOT NULL DEFAULT 0.0,
                total_vat REAL NOT NULL DEFAULT 0.0,
                total_non_vat REAL NOT NULL DEFAULT 0.0,
                total_amount REAL NOT NULL DEFAULT 0.0,
                created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
                updated_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
            )
        """)
        sqlite_conn.commit()
    except Exception as e:
        print(json.dumps({"status": "error", "message": f"Cannot connect to SQLite database {db_file}: {str(e)}"}))
        sys.exit(1)

    # Import pyodbc
    try:
        import pyodbc
    except ImportError:
        print(json.dumps({"status": "error", "message": "pyodbc module is not installed in Python environment."}))
        sys.exit(1)

    # Build ODBC connection string
    conn_str = f"DSN={dsn_name}"
    if username:
        conn_str += f";UID={username}"
    if password:
        conn_str += f";PWD={password}"

    # Try connecting to AS400 ODBC
    try:
        as400_conn = pyodbc.connect(conn_str, autocommit=True)
        as400_cur = as400_conn.cursor()
    except Exception as e:
        print(json.dumps({
            "status": "error",
            "message": f"Failed to connect to AS400 DSN '{dsn_name}': {str(e)}"
        }))
        sys.exit(1)

    imported_count = 0
    updated_count = 0
    skipped_count = 0

    # Build existing map for duplicate detection
    sqlite_cur.execute("SELECT id, store_code, register_number, entry_date, transaction_number, invoice_number FROM ej_entries")
    existing_map = {}
    for r in sqlite_cur.fetchall():
        key = (str(r[1]).strip(), str(r[2]).strip(), str(r[3]).strip(), str(r[4]).strip(), str(r[5]).strip())
        existing_map[key] = r[0]

    try:
        # Search available tables in AS400 DSN
        tables = as400_cur.tables().fetchall()
        table_names = [t[2] for t in tables if len(t) > 2 and t[2]]

        # Candidate table names for sales/journal transactions
        candidate_tables = [t for t in table_names if any(w in t.upper() for w in ['EJ', 'TRX', 'TRAN', 'SALE', 'INVOICE', 'HEADER', 'SLS'])]
        
        # If no specific candidate found, use available tables
        target_table = candidate_tables[0] if candidate_tables else (table_names[0] if table_names else "")

        if not target_table:
            print(json.dumps({
                "status": "success",
                "imported": 0,
                "updated": 0,
                "skipped": 0,
                "message": f"Connected to {dsn_name} successfully, but no transaction tables were found."
            }))
            sys.exit(0)

        # Query columns of target table
        cols = as400_cur.columns(table=target_table).fetchall()
        col_names = [c[3].upper() for c in cols]

        # Build dynamic select query
        query = f"SELECT * FROM {target_table}"
        where_parts = []
        params = []

        if store_code:
            # Look for store column
            store_cols = [c for c in col_names if any(s in c for s in ['STR', 'STORE', 'STORE_CODE', 'STRNUM'])]
            if store_cols:
                where_parts.append(f"{store_cols[0]} = ?")
                params.append(store_code)

        if where_parts:
            query += " WHERE " + " AND ".join(where_parts)

        as400_cur.execute(query, params)
        rows = as400_cur.fetchmany(500)

        col_headers = [desc[0].upper() for desc in as400_cur.description]

        for row in rows:
            r_dict = dict(zip(col_headers, row))

            # Extract fields with fallback mappings
            e_date = str(r_dict.get('DATE', r_dict.get('TRX_DATE', r_dict.get('ENTRY_DATE', date_from or datetime.date.today().strftime('%Y-%m-%d')))) or '').strip()
            e_time = str(r_dict.get('TIME', r_dict.get('TRX_TIME', '00:00')) or '').strip()
            s_code = str(r_dict.get('STORE', r_dict.get('STR_NO', r_dict.get('STORE_CODE', store_code))) or store_code).strip()
            reg_no = str(r_dict.get('REG_NO', r_dict.get('REGISTER', r_dict.get('POS_NO', '1'))) or '').strip()
            trx_no = str(r_dict.get('TRX_NO', r_dict.get('TRANSACTION_NO', r_dict.get('TRX', ''))) or '').strip()
            inv_no = str(r_dict.get('INV_NO', r_dict.get('INVOICE_NO', r_dict.get('RECEIPT_NO', ''))) or '').strip()
            mbr_no = str(r_dict.get('MBR_NO', r_dict.get('MEMBER_NO', r_dict.get('CARD_NO', ''))) or '').strip()
            cust_name = str(r_dict.get('NAME', r_dict.get('CUST_NAME', r_dict.get('MEMBER_NAME', ''))) or '').strip()
            sales_assoc = str(r_dict.get('CASHIER', r_dict.get('SALES_ASSOC', r_dict.get('OPERATOR', ''))) or '').strip()
            assoc_id = str(r_dict.get('CASHIER_ID', r_dict.get('ASSOC_ID', r_dict.get('EMP_ID', ''))) or '').strip()
            till_no = str(r_dict.get('TILL_NO', r_dict.get('TILL', '0000')) or '0000').strip()

            subtotal = float(r_dict.get('SUBTOTAL', r_dict.get('TOTAL_SALES', r_dict.get('GROSS_AMT', 0.0))) or 0.0)
            vat = float(r_dict.get('VAT', r_dict.get('VAT_AMT', 0.0))) or 0.0
            non_vat = float(r_dict.get('NON_VAT', r_dict.get('NON_VAT_AMT', 0.0))) or 0.0
            total_amt = float(r_dict.get('TOTAL_AMT', r_dict.get('NET_AMT', r_dict.get('AMOUNT', subtotal))) or subtotal)

            items = []
            if 'SKU' in r_dict:
                items.append({
                    "sku": str(r_dict.get('SKU', '')),
                    "description": str(r_dict.get('DESC', r_dict.get('ITEM_DESC', ''))),
                    "quantity": float(r_dict.get('QTY', 1) or 1),
                    "unit_price": float(r_dict.get('PRICE', total_amt) or total_amt),
                    "amount": float(r_dict.get('ITEM_AMT', total_amt) or total_amt)
                })

            tenders = []
            if 'TENDER' in r_dict or 'TENDER_NAME' in r_dict:
                tenders.append({
                    "name": str(r_dict.get('TENDER', r_dict.get('TENDER_NAME', 'Cash'))),
                    "amount": total_amt
                })

            items_json = json.dumps(items)
            tenders_json = json.dumps(tenders)

            dup_key = (s_code, reg_no, e_date, trx_no, inv_no)

            if dup_key in existing_map:
                existing_id = existing_map[dup_key]
                sqlite_cur.execute("""
                    UPDATE ej_entries SET
                        entry_date = ?, entry_time = ?, member_number = ?, customer_name = ?,
                        sales_associate = ?, associate_id = ?, till_number = ?,
                        items = ?, tenders = ?, subtotal = ?, total_vat = ?, total_non_vat = ?,
                        total_amount = ?, updated_at = datetime('now', 'localtime')
                    WHERE id = ?
                """, (e_date, e_time, mbr_no, cust_name, sales_assoc, assoc_id, till_no, items_json, tenders_json, subtotal, vat, non_vat, total_amt, existing_id))
                updated_count += 1
            else:
                sqlite_cur.execute("""
                    INSERT INTO ej_entries (
                        entry_date, entry_time, store_code, register_number, transaction_number,
                        invoice_number, member_number, customer_name, sales_associate, associate_id,
                        till_number, items, tenders, subtotal, total_vat, total_non_vat, total_amount,
                        created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now', 'localtime'), datetime('now', 'localtime'))
                """, (e_date, e_time, s_code, reg_no, trx_no, inv_no, mbr_no, cust_name, sales_assoc, assoc_id, till_no, items_json, tenders_json, subtotal, vat, non_vat, total_amt))
                existing_map[dup_key] = sqlite_cur.lastrowid
                imported_count += 1

        sqlite_conn.commit()
        as400_conn.close()
        sqlite_conn.close()

        print(json.dumps({
            "status": "success",
            "imported": imported_count,
            "updated": updated_count,
            "skipped": skipped_count,
            "table_used": target_table,
            "message": f"Successfully processed {imported_count + updated_count} transactions from AS400 ({imported_count} new, {updated_count} updated)."
        }))

    except Exception as e:
        print(json.dumps({
            "status": "error",
            "message": f"Error querying AS400 table: {str(e)}"
        }))

if __name__ == "__main__":
    main()
