<?php
// import_as400_ajax.php - Handles AS400 import via AJAX
header('Content-Type: application/json');
require_once __DIR__ . '/ej_db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method.']);
    exit;
}

$storeCode = trim($_POST['store_code'] ?? '');
$dsnName   = trim($_POST['dsn_name'] ?? '');
$username  = trim($_POST['username'] ?? '');
$password  = trim($_POST['password'] ?? '');
$dateFrom  = trim($_POST['date_from'] ?? '');
$dateTo    = trim($_POST['date_to'] ?? '');

// Load saved config if available
$configFile = __DIR__ . '/as400_config.json';
if (file_exists($configFile)) {
    $cfg = json_decode(file_get_contents($configFile), true);
    if (is_array($cfg)) {
        if ($username === '' && !empty($cfg['username'])) $username = $cfg['username'];
        if ($password === '' && !empty($cfg['password'])) $password = $cfg['password'];
        if ($dsnName === '' && !empty($cfg['dsn_name'])) $dsnName = $cfg['dsn_name'];
    }
}

if ($dsnName === '') $dsnName = 'mms_as400';

$pythonExe = 'C:\\python32\\python.exe';
if (!file_exists($pythonExe)) {
    $pythonExe = 'python';
}

$scriptPath = __DIR__ . '/scripts/import_as400.py';
$dbFile = __DIR__ . '/ej.db';

if (!file_exists($scriptPath)) {
    echo json_encode(['status' => 'error', 'message' => 'AS400 import script not found: ' . $scriptPath]);
    exit;
}

$cmd = escapeshellarg($pythonExe) . ' ' .
       escapeshellarg($scriptPath) . ' ' .
       escapeshellarg($storeCode) . ' ' .
       escapeshellarg($dsnName) . ' ' .
       escapeshellarg($username) . ' ' .
       escapeshellarg($password) . ' ' .
       escapeshellarg($dateFrom) . ' ' .
       escapeshellarg($dateTo) . ' ' .
       escapeshellarg($dbFile);

$output = [];
$returnVar = 0;
exec($cmd . ' 2>&1', $output, $returnVar);

$outputStr = implode("\n", $output);
$json = json_decode($outputStr, true);

if (is_array($json)) {
    echo json_encode($json);
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'Error executing AS400 import script.',
        'raw_output' => $outputStr
    ]);
}
