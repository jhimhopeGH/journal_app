<?php
// register_master.php - Lists register master records, supports search
require_once __DIR__ . '/db.php';
$currentPage = 'register_master';

$search = isset($_GET['q']) ? trim($_GET['q']) : '';
$saved  = isset($_GET['saved']) ? (int)$_GET['saved'] : 0;

$rows   = getAllRegisterMasters($search);
$stores = getAllStoreMasters();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Register Master - Electronic Journal</title>
<link rel="stylesheet" href="style.css">
<style>
/* Import Modal */
.modal-overlay {
    display: none;
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,0.55);
    z-index: 1000;
    align-items: center;
    justify-content: center;
}
.modal-overlay.active { display: flex; }
.modal-box {
    background: #1e2130;
    border: 1px solid #2d3555;
    border-radius: 12px;
    padding: 32px;
    max-width: 420px;
    width: 100%;
    box-shadow: 0 8px 40px rgba(0,0,0,0.5);
    position: relative;
}
.modal-box h2 { margin: 0 0 8px; font-size: 17px; color: #e8ecf4; }
.modal-box p  { margin: 0 0 18px; font-size: 13px; color: #8892a4; }
.modal-box label { font-size: 12px; color: #8892a4; margin-bottom: 4px; display: block; }
.modal-box select,
.modal-box input[type=text] {
    width: 100%;
    padding: 9px 12px;
    border-radius: 7px;
    border: 1px solid #2d3555;
    background: #141824;
    color: #e8ecf4;
    font-size: 13px;
    margin-bottom: 10px;
    box-sizing: border-box;
}
.modal-box .modal-actions { display: flex; gap: 10px; margin-top: 18px; }
.modal-box .modal-actions button { flex: 1; padding: 10px; border-radius: 8px; font-size: 13px; font-weight: 600; cursor: pointer; border: none; }
.btn-import-go  { background: linear-gradient(135deg, #4f8ef7, #2d6cdf); color: #fff; }
.btn-cancel     { background: #252a3d; color: #8892a4; }
.modal-close {
    position: absolute; top: 12px; right: 16px;
    background: none; border: none; color: #8892a4;
    font-size: 20px; cursor: pointer; line-height: 1;
}
#importStatus {
    margin-top: 14px; font-size: 13px; display: none;
    padding: 10px 14px; border-radius: 8px;
}
#importStatus.success { background: #1a3a28; color: #3fca7f; border: 1px solid #2d5a3f; }
#importStatus.error   { background: #3a1a1a; color: #f07070; border: 1px solid #5a2d2d; }
#importSpinner { display: none; text-align: center; padding: 12px 0; color: #8892a4; font-size: 13px; }
</style>
</head>
<body>
<div class="app-shell">
    <?php require __DIR__ . '/partials/nav.php'; ?>

    <main class="main-content">
        <div class="top-nav">
            <a href="register_master_entry.php">+ New Entry</a>
            <a href="register_master.php">View Records</a>
            <button class="btn" onclick="openImportModal()" style="background: linear-gradient(135deg,#a855f7,#7c3aed); color:#fff; border:none; padding:8px 16px; border-radius:8px; cursor:pointer; font-size:13px; font-weight:600;">
                ⬆ Import TopSpeed
            </button>
        </div>

        <div class="page-header">
            <h1>Register Master</h1>
            <p>Manage register / POS machine details by store.</p>
        </div>

        <?php if ($saved): ?>
            <div class="success">Register entry saved successfully.</div>
        <?php endif; ?>
        <?php if (isset($_GET['deleted']) && $_GET['deleted'] == 1): ?>
            <div class="success">Register entry deleted successfully.</div>
        <?php endif; ?>

        <div class="panel">
        <form class="search-bar" method="GET" action="register_master.php">
            <input type="text" name="q" placeholder="Search by store code, register no., serial, permit, or MIN..."
                   value="<?php echo htmlspecialchars($search); ?>">
            <button type="submit">Search</button>
        </form>

        <table>
        <thead>
            <tr>
                <th style="width: 60px;">ID</th>
                <th style="width: 120px;">Store Code</th>
                <th style="width: 110px;">Reg No.</th>
                <th style="width: 150px;">Serial No.</th>
                <th style="width: 190px;">Permit No.</th>
                <th style="width: 190px;">MIN No.</th>
                <th style="width: 160px;">Updated</th>
                <th style="width: 120px;"></th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($rows)): ?>
                <tr><td colspan="8" style="text-align:center; padding:20px; color:#888;">No register records found.</td></tr>
            <?php else: ?>
                <?php foreach ($rows as $row): ?>
                <tr>
                    <td><?php echo (int)$row['id']; ?></td>
                    <td><strong style="color: #2d6cdf;"><?php echo htmlspecialchars($row['store_code']); ?></strong></td>
                    <td><strong><?php echo htmlspecialchars($row['reg_no']); ?></strong></td>
                    <td><?php echo htmlspecialchars($row['serial_number']); ?></td>
                    <td><?php echo htmlspecialchars($row['permit_number']); ?></td>
                    <td><?php echo htmlspecialchars($row['min_number']); ?></td>
                    <td><?php echo htmlspecialchars($row['updated_at']); ?></td>
                    <td style="white-space: nowrap;">
                        <a class="btn" style="padding: 4px 8px; font-size: 11px;" href="register_master_entry.php?id=<?php echo (int)$row['id']; ?>">Edit</a>
                        <a class="btn btn-secondary" style="padding: 4px 8px; font-size: 11px; background: #dc3545;" href="register_master_delete.php?id=<?php echo (int)$row['id']; ?>" onclick="return confirm('Are you sure you want to delete this register?');">Delete</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
        </table>
        </div>
    </main>
</div>

<!-- Import TopSpeed Modal -->
<div class="modal-overlay" id="importModal">
    <div class="modal-box">
        <button class="modal-close" onclick="closeImportModal()">✕</button>
        <h2>⬆ Import from TopSpeed</h2>
        <p>Select or type the Store Code to associate with the imported REGSET.TPS records.</p>

        <label for="importStoreSelect">Choose Store Code</label>
        <?php if (!empty($stores)): ?>
            <select id="importStoreSelect" onchange="document.getElementById('importStoreCode').value = this.value;">
                <option value="">-- Select from Store Master --</option>
                <?php foreach ($stores as $s): ?>
                    <option value="<?php echo htmlspecialchars($s['store_code']); ?>">
                        <?php echo htmlspecialchars($s['store_code'] . ' - ' . $s['store_name']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        <?php endif; ?>

        <label for="importStoreCode">Or type Store Code manually</label>
        <input type="text" id="importStoreCode" placeholder="e.g. 12027" />

        <div id="importSpinner">⏳ Importing... please wait.</div>
        <div id="importStatus"></div>

        <div class="modal-actions">
            <button class="btn-cancel" onclick="closeImportModal()">Cancel</button>
            <button class="btn-import-go" onclick="runImport()">Import Now</button>
        </div>
    </div>
</div>

<script>
function openImportModal() {
    document.getElementById('importModal').classList.add('active');
    document.getElementById('importStatus').style.display = 'none';
    document.getElementById('importStatus').textContent = '';
    document.getElementById('importSpinner').style.display = 'none';
    const sel = document.getElementById('importStoreSelect');
    if (sel) { sel.value = ''; }
    document.getElementById('importStoreCode').value = '';
}

function closeImportModal() {
    document.getElementById('importModal').classList.remove('active');
}

document.getElementById('importModal').addEventListener('click', function(e) {
    if (e.target === this) closeImportModal();
});

function runImport() {
    const storeCode = document.getElementById('importStoreCode').value.trim();
    if (!storeCode) {
        showStatus('Please enter or select a Store Code before importing.', false);
        return;
    }

    document.getElementById('importSpinner').style.display = 'block';
    document.getElementById('importStatus').style.display = 'none';

    const fd = new FormData();
    fd.append('store_code', storeCode);

    fetch('import_regset_ajax.php', { method: 'POST', body: fd })
        .then(r => r.json())
        .then(data => {
            document.getElementById('importSpinner').style.display = 'none';
            if (data.success) {
                const errNote = data.errors && data.errors.length > 0
                    ? ` (${data.errors.length} error(s))` : '';
                showStatus(`✅ Done! ${data.inserted} record(s) imported / updated from ${data.total} rows.${errNote}`, true);
                setTimeout(() => { window.location.reload(); }, 2000);
            } else {
                showStatus('❌ Import failed: ' + (data.error || 'Unknown error.'), false);
            }
        })
        .catch(err => {
            document.getElementById('importSpinner').style.display = 'none';
            showStatus('❌ Network error: ' + err.message, false);
        });
}

function showStatus(msg, success) {
    const el = document.getElementById('importStatus');
    el.textContent = msg;
    el.className = success ? 'success' : 'error';
    el.style.display = 'block';
}
</script>
</body>
</html>
