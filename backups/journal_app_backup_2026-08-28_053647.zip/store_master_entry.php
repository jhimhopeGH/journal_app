<?php
// store_master_entry.php - New / Edit store master entry form
require_once __DIR__ . '/db.php';
$currentPage = 'store_master';

// If editing, load existing record
$editId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$store = [
    'store_code' => '',
    'store_name' => '',
    'serial_number' => '',
    'min_number' => '',
    'permit_number' => '',
    'header' => '',
    'footer' => ''
];

if ($editId > 0) {
    $existing = getStoreMasterById($editId);
    if ($existing) {
        $store = $existing;
    }
}

$isEdit = $editId > 0 && isset($existing) && $existing;
$pageTitle = $isEdit ? 'Edit Store Entry' : 'New Store Entry';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title><?php echo $pageTitle; ?> - Electronic Journal</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="app-shell">
    <?php require __DIR__ . '/partials/nav.php'; ?>

    <main class="main-content">
        <div class="top-nav">
            <a href="store_master_entry.php">+ New Entry</a>
            <a href="store_master.php">View Records</a>
        </div>

        <div class="page-header">
            <h1><?php echo $pageTitle; ?></h1>
            <p>Fill in the store details below and save.</p>
        </div>

        <div class="panel" style="max-width: 560px;">
        <form action="store_master_save.php" method="POST" id="storeMasterForm">
            <?php if ($isEdit): ?>
                <input type="hidden" name="edit_id" value="<?php echo $editId; ?>">
            <?php endif; ?>

            <label for="store_code">Store Code</label>
            <input type="text" id="store_code" name="store_code"
                   value="<?php echo htmlspecialchars($store['store_code']); ?>" required
                   placeholder="e.g. STR-001">
            <p class="hint">Short code identifying the store.</p>

            <label for="store_name">Store Name</label>
            <input type="text" id="store_name" name="store_name"
                   value="<?php echo htmlspecialchars($store['store_name']); ?>" required
                   placeholder="e.g. Main Branch">
            <p class="hint">Full display name for the store.</p>

            <label for="header">Header</label>
            <textarea id="header" name="header" rows="3"
                      placeholder="Receipt header text..."><?php echo htmlspecialchars($store['header']); ?></textarea>
            <p class="hint">Text printed at the top of receipts.</p>

            <label for="footer">Footer</label>
            <textarea id="footer" name="footer" rows="3"
                      placeholder="Receipt footer text..."><?php echo htmlspecialchars($store['footer']); ?></textarea>
            <p class="hint">Text printed at the bottom of receipts.</p>

            <button type="submit"><?php echo $isEdit ? 'Update Store' : 'Save Store'; ?></button>
        </form>
        </div>
    </main>
</div>
</body>
</html>
