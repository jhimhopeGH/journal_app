<?php
// receipt_reprint.php - Receipt Reprint Records Management, Search, Filter & Printing
require_once __DIR__ . '/ej_db.php';
$currentPage = 'receipt_reprint';

$search      = isset($_GET['q']) ? trim($_GET['q']) : '';
$storeFilter = isset($_GET['store']) ? trim($_GET['store']) : '';
$regFilter   = isset($_GET['reg']) ? trim($_GET['reg']) : '';
$from        = isset($_GET['from']) ? trim($_GET['from']) : '';
$to          = isset($_GET['to']) ? trim($_GET['to']) : '';
$page        = max(1, isset($_GET['page']) ? (int)$_GET['page'] : 1);
$perPage     = isset($_GET['per_page']) && in_array((int)$_GET['per_page'], [25, 50, 100, 200]) ? (int)$_GET['per_page'] : 50;

$totalRows  = countEjEntries($search, $storeFilter, $regFilter, $from, $to);
$totalPages = max(1, ceil($totalRows / $perPage));
$page       = min($page, $totalPages);
$offset     = ($page - 1) * $perPage;
$rows       = getEjEntries($search, $storeFilter, $regFilter, $from, $to, $perPage, $offset);

$stores          = getAllStoreMasters();
$uniqueRegisters = getUniqueEjRegisters();

$as400CfgFile = __DIR__ . '/as400_config.json';
$as400Config  = ['dsn_name' => 'mms_as400', 'username' => '', 'password' => '', 'library' => 'MMLTSLIB'];
if (file_exists($as400CfgFile)) {
    $c = json_decode(file_get_contents($as400CfgFile), true);
    if (is_array($c)) $as400Config = array_merge($as400Config, $c);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Receipt Reprint - Electronic Journal</title>
<link rel="stylesheet" href="style.css">
<style>
    .top-nav { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; margin-bottom: 16px; }
    .top-nav .btn, .top-nav a.btn, .top-nav button.btn {
        padding: 8px 16px; font-size: 13px; font-weight: 600; text-decoration: none;
        display: inline-flex; align-items: center; gap: 6px; color: #ffffff !important;
        margin-top: 0; background: #0284c7;
    }
    .top-nav .btn-secondary, .top-nav a.btn-secondary { background: #475569 !important; color: #ffffff !important; }
    .top-nav .btn:hover { opacity: 0.92; color: #ffffff !important; }
    .badge-pill { display: inline-block; padding: 2px 8px; font-size: 11px; font-weight: 600; border-radius: 9999px; background: #f1f5f9; color: #334155; }
    .badge-tender { background: #ede9fe; color: #6d28d9; }
    .badge-member { background: #e0e7ff; color: #4338ca; }
    .items-tooltip { max-width: 260px; white-space: normal; font-size: 12px; color: #475569; line-height: 1.3; }
    .modal-overlay { display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(15,23,42,0.65); backdrop-filter: blur(2px); z-index: 9999; justify-content: center; align-items: center; }
    .modal-overlay.active { display: flex; }
    .modal-box { background: #ffffff; border-radius: 10px; width: 520px; max-width: 95vw; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.2); overflow: hidden; }
    .modal-header { padding: 16px 20px; background: #0284c7; color: #ffffff; display: flex; justify-content: space-between; align-items: center; }
    .modal-header h3 { margin: 0; font-size: 16px; font-weight: 600; }
    .modal-close { background: none; border: none; color: #ffffff; font-size: 20px; cursor: pointer; line-height: 1; }
    .modal-body { padding: 20px; }
    .log-terminal { background: #0f172a; color: #38bdf8; font-family: 'Courier New', Courier, monospace; font-size: 12px; padding: 12px; border-radius: 6px; height: 140px; overflow-y: auto; white-space: pre-wrap; margin-top: 14px; display: none; }
</style>
</head>
<body>
<div class="app-shell">
    <?php require __DIR__ . '/partials/nav.php'; ?>
    <main class="main-content">
        <div class="top-nav">
            <a href="ej_entry.php" class="btn">+ New Entry</a>
            <a href="receipt_reprint.php" class="btn btn-secondary">View Records</a>
            <button type="button" class="btn" id="btn_open_as400" style="background:#0284c7;">⚡ Import AS400</button>
            <button type="button" class="btn" id="btn_batch_print" style="background:#7c3aed;">🧾 Batch Receipt Print</button>
            <button type="button" class="btn btn-secondary" id="btn_open_as400_config">⚙️ AS400 Settings</button>
        </div>

        <div class="page-header">
            <h1>Receipt Reprint</h1>
            <p>Browse and reprint Electronic Journal transactions as 80mm thermal receipts (Database: <code>ej.db</code>).</p>
        </div>

        <div class="panel">
            <form class="search-bar" method="GET" action="receipt_reprint.php" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end;margin-bottom:16px;">
                <label style="margin:0;font-size:12px;color:#64748b;">
                    Search
                    <input type="text" name="q" placeholder="Invoice, Trx, Member, Name, SKU..." value="<?php echo htmlspecialchars($search); ?>" style="width:260px;">
                </label>
                <label style="margin:0;font-size:12px;color:#64748b;">
                    Store
                    <select name="store" style="padding:7px 10px;">
                        <option value="">All Stores</option>
                        <?php foreach ($stores as $s): ?>
                            <option value="<?php echo htmlspecialchars($s['store_code']); ?>" <?php echo ($storeFilter === $s['store_code']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($s['store_code'] . ' - ' . $s['store_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <label style="margin:0;font-size:12px;color:#64748b;">
                    Register
                    <select name="reg" style="padding:7px 10px;">
                        <option value="">All Regs</option>
                        <?php foreach ($uniqueRegisters as $ur): ?>
                            <option value="<?php echo htmlspecialchars($ur); ?>" <?php echo ($regFilter === $ur) ? 'selected' : ''; ?>>
                                Reg <?php echo htmlspecialchars($ur); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <label style="margin:0;font-size:12px;color:#64748b;">
                    From <input type="date" name="from" value="<?php echo htmlspecialchars($from); ?>" style="padding:7px 8px;">
                </label>
                <label style="margin:0;font-size:12px;color:#64748b;">
                    To <input type="date" name="to" value="<?php echo htmlspecialchars($to); ?>" style="padding:7px 8px;">
                </label>
                <button type="submit" class="btn" style="padding:8px 16px;">Filter</button>
                <a href="receipt_reprint.php" class="btn btn-secondary" style="padding:8px 12px;">Reset</a>
                <div style="margin-left:auto;font-size:13px;color:#64748b;align-self:center;">
                    Total: <strong><?php echo number_format($totalRows); ?></strong> records
                </div>
            </form>

            <form id="batchPrintForm" method="GET" action="receipt_print_batch.php" target="_blank">
                <input type="hidden" name="ids" id="batch_ids_input" value="">
            </form>

            <?php if (empty($rows)): ?>
                <p class="empty-state">No EJ entries found. Create a <a href="ej_entry.php">New Entry</a> or click <strong>Import AS400</strong>.</p>
            <?php else: ?>
                <table style="font-size:13px;">
                    <thead>
                        <tr>
                            <th style="width:32px;text-align:center;"><input type="checkbox" id="select_all_checkbox" title="Select All"></th>
                            <th style="width:60px;">ID</th>
                            <th style="width:100px;">Date &amp; Time</th>
                            <th style="width:70px;">Store</th>
                            <th style="width:60px;">Reg</th>
                            <th>Invoice / Trx #</th>
                            <th>Member / Customer</th>
                            <th>Items</th>
                            <th style="text-align:right;width:110px;">Total (₱)</th>
                            <th style="width:130px;">Tender</th>
                            <th style="width:160px;text-align:center;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($rows as $row): ?>
                        <?php
                            $itemsDecoded   = json_decode($row['items'] ?? '[]', true);
                            $itemCount      = is_array($itemsDecoded) ? count($itemsDecoded) : 0;
                            $firstItemDesc  = ($itemCount > 0 && isset($itemsDecoded[0]['description'])) ? $itemsDecoded[0]['description'] : ($itemCount > 0 ? ($itemsDecoded[0]['sku'] ?? '') : 'No items');
                            $tendersDecoded = json_decode($row['tenders'] ?? '[]', true);
                            $tenderSummary  = [];
                            if (is_array($tendersDecoded)) {
                                foreach ($tendersDecoded as $td) {
                                    if (!empty($td['name']) && (float)($td['amount'] ?? 0) >= 0) $tenderSummary[] = $td['name'];
                                }
                            }
                            $tenderText = !empty($tenderSummary) ? implode(', ', $tenderSummary) : 'Cash';
                        ?>
                        <tr>
                            <td style="text-align:center;"><input type="checkbox" class="row-checkbox" value="<?php echo (int)$row['id']; ?>"></td>
                            <td><?php echo (int)$row['id']; ?></td>
                            <td>
                                <div><?php echo htmlspecialchars($row['entry_date']); ?></div>
                                <div style="font-size:11px;color:#64748b;"><?php echo htmlspecialchars($row['entry_time']); ?></div>
                            </td>
                            <td><span class="badge-pill"><?php echo htmlspecialchars($row['store_code']); ?></span></td>
                            <td><strong><?php echo htmlspecialchars($row['register_number']); ?></strong></td>
                            <td>
                                <div style="font-weight:600;color:#0284c7;"><?php echo htmlspecialchars($row['invoice_number'] ?: '—'); ?></div>
                                <div style="font-size:11px;color:#64748b;">Trx: <?php echo htmlspecialchars($row['transaction_number'] ?: '—'); ?></div>
                            </td>
                            <td>
                                <?php if (!empty($row['member_number'])): ?>
                                    <div><span class="badge-pill badge-member"><?php echo htmlspecialchars($row['member_number']); ?></span></div>
                                <?php endif; ?>
                                <div style="font-weight:500;"><?php echo htmlspecialchars($row['customer_name'] ?: 'Walk-in'); ?></div>
                            </td>
                            <td>
                                <div class="items-tooltip" title="<?php echo htmlspecialchars($firstItemDesc); ?>">
                                    <span class="badge-pill"><?php echo $itemCount; ?> item<?php echo $itemCount === 1 ? '' : 's'; ?></span>
                                    <?php if ($itemCount > 0): ?>
                                        <div style="font-size:11px;color:#475569;margin-top:2px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:160px;"><?php echo htmlspecialchars($firstItemDesc); ?></div>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td style="text-align:right;font-weight:bold;color:#0f172a;">₱<?php echo number_format((float)$row['total_amount'], 2); ?></td>
                            <td><span class="badge-pill badge-tender"><?php echo htmlspecialchars($tenderText); ?></span></td>
                            <td style="text-align:center;white-space:nowrap;">
                                <a class="btn" style="padding:3px 8px;font-size:11px;background:#7c3aed;" href="receipt_print.php?id=<?php echo (int)$row['id']; ?>" target="_blank">🧾 Print</a>
                                <a class="btn" style="padding:3px 8px;font-size:11px;" href="ej_entry.php?id=<?php echo (int)$row['id']; ?>">Edit</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

                <?php if ($totalPages > 1): ?>
                <div style="display:flex;justify-content:space-between;align-items:center;margin-top:16px;padding-top:12px;border-top:1px solid #e2e8f0;">
                    <div style="font-size:13px;color:#64748b;">Showing page <?php echo $page; ?> of <?php echo $totalPages; ?></div>
                    <div style="display:flex;gap:6px;">
                        <?php if ($page > 1): ?>
                            <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page - 1])); ?>" class="btn btn-secondary" style="padding:4px 10px;font-size:12px;">← Prev</a>
                        <?php endif; ?>
                        <?php for ($p = max(1, $page - 3); $p <= min($totalPages, $page + 3); $p++): ?>
                            <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $p])); ?>" class="btn <?php echo ($p === $page) ? '' : 'btn-secondary'; ?>" style="padding:4px 10px;font-size:12px;"><?php echo $p; ?></a>
                        <?php endfor; ?>
                        <?php if ($page < $totalPages): ?>
                            <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page + 1])); ?>" class="btn btn-secondary" style="padding:4px 10px;font-size:12px;">Next →</a>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </main>
</div>

<!-- AS400 Import Modal -->
<div class="modal-overlay" id="as400_modal">
    <div class="modal-box">
        <div class="modal-header"><h3>⚡ Import from AS400 (ODBC DSN: mms_as400)</h3><button type="button" class="modal-close" id="modal_close_as400">&times;</button></div>
        <div class="modal-body">
            <form id="as400ImportForm">
                <div style="margin-bottom:12px;">
                    <label style="font-size:12px;display:block;">Store Code:
                        <select name="store_code" required style="width:100%;">
                            <option value="">-- Select Store --</option>
                            <?php foreach ($stores as $s): ?>
                                <option value="<?php echo htmlspecialchars($s['store_code']); ?>"><?php echo htmlspecialchars($s['store_code'] . ' - ' . $s['store_name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </label>
                </div>
                <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;margin-bottom:12px;">
                    <label style="font-size:12px;font-weight:600;">Date <span style="color:#ef4444;">*</span>:<input type="date" name="date_from" required style="width:100%;padding:6px 8px;border-radius:6px;border:1px solid #cbd5e1;"></label>
                    <label style="font-size:12px;font-weight:600;">Reg. No # <span style="color:#ef4444;">*</span>:<input type="text" name="reg_no" required placeholder="e.g. 104" style="width:100%;padding:6px 8px;border-radius:6px;border:1px solid #cbd5e1;"></label>
                    <label style="font-size:12px;font-weight:600;">Traxn No. <span style="color:#ef4444;">*</span>:<input type="text" name="traxn_no" required placeholder="e.g. 1521" style="width:100%;padding:6px 8px;border-radius:6px;border:1px solid #cbd5e1;"></label>
                </div>
                <div style="display:flex;gap:10px;align-items:center;">
                    <button type="submit" class="btn" id="btn_run_import" style="padding:9px 20px;font-weight:bold;background:#0284c7;">🚀 Start AS400 Import</button>
                    <span id="import_spinner" style="display:none;font-size:13px;color:#0284c7;">⏳ Connecting to AS400...</span>
                </div>
                <div class="log-terminal" id="as400_terminal"></div>
            </form>
        </div>
    </div>
</div>

<!-- AS400 Settings Modal -->
<div class="modal-overlay" id="as400_config_modal">
    <div class="modal-box" style="width:480px;">
        <div class="modal-header" style="background:#1e293b;"><h3>⚙️ AS400 Connection Settings</h3><button type="button" class="modal-close" id="modal_close_as400_config">&times;</button></div>
        <div class="modal-body">
            <form id="as400ConfigForm">
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px;">
                    <label style="font-size:12px;">ODBC DSN Name:<input type="text" name="dsn_name" value="<?php echo htmlspecialchars($as400Config['dsn_name']); ?>" required></label>
                    <label style="font-size:12px;">Library Name:<input type="text" name="library" value="<?php echo htmlspecialchars($as400Config['library']); ?>" required></label>
                </div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:16px;">
                    <label style="font-size:12px;">AS400 User ID:<input type="text" name="username" value="<?php echo htmlspecialchars($as400Config['username']); ?>" placeholder="e.g. QSECOFR / user" required></label>
                    <label style="font-size:12px;">AS400 Password:<input type="password" name="password" value="<?php echo htmlspecialchars($as400Config['password']); ?>" placeholder="Password" required></label>
                </div>
                <div style="display:flex;gap:10px;align-items:center;">
                    <button type="submit" class="btn" id="btn_save_as400_config" style="padding:8px 18px;font-weight:bold;background:#0284c7;">💾 Save &amp; Test Connection</button>
                    <span id="as400_config_status" style="font-size:12px;font-weight:500;"></span>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const selectAll     = document.getElementById('select_all_checkbox');
    const checkboxes    = document.querySelectorAll('.row-checkbox');
    const btnBatch      = document.getElementById('btn_batch_print');
    const batchForm     = document.getElementById('batchPrintForm');
    const batchInput    = document.getElementById('batch_ids_input');

    if (selectAll) selectAll.addEventListener('change', () => checkboxes.forEach(cb => cb.checked = selectAll.checked));

    btnBatch.addEventListener('click', () => {
        const ids = [];
        checkboxes.forEach(cb => { if (cb.checked) ids.push(cb.value); });
        if (!ids.length) { alert('Please select at least one record to print.'); return; }
        batchInput.value = ids.join(',');
        batchForm.submit();
    });

    // Modal helpers
    const openModal  = id => document.getElementById(id)?.classList.add('active');
    const closeModal = id => document.getElementById(id)?.classList.remove('active');
    const onOverlay  = (id) => document.getElementById(id)?.addEventListener('click', e => { if (e.target.id === id) closeModal(id); });

    document.getElementById('btn_open_as400')?.addEventListener('click', () => openModal('as400_modal'));
    document.getElementById('modal_close_as400')?.addEventListener('click', () => closeModal('as400_modal'));
    onOverlay('as400_modal');

    document.getElementById('btn_open_as400_config')?.addEventListener('click', () => openModal('as400_config_modal'));
    document.getElementById('modal_close_as400_config')?.addEventListener('click', () => closeModal('as400_config_modal'));
    onOverlay('as400_config_modal');

    // AS400 config save
    document.getElementById('as400ConfigForm')?.addEventListener('submit', async e => {
        e.preventDefault();
        const btn = document.getElementById('btn_save_as400_config');
        const status = document.getElementById('as400_config_status');
        btn.disabled = true; status.textContent = '⏳ Testing...'; status.style.color = '#0284c7';
        try {
            const resp = await fetch('save_as400_config_ajax.php', { method: 'POST', body: new FormData(e.target) });
            const data = await resp.json();
            if (data.status === 'success') {
                status.textContent = data.test_success ? '✓ Saved & Connected!' : '⚠️ Saved, test failed: ' + (data.test_message || '');
                status.style.color = data.test_success ? '#16a34a' : '#e11d48';
                if (data.test_success) setTimeout(() => closeModal('as400_config_modal'), 1200);
            } else { status.textContent = '❌ ' + (data.message || 'Error'); status.style.color = '#e11d48'; }
        } catch(err) { status.textContent = '❌ ' + err.message; status.style.color = '#e11d48'; }
        finally { btn.disabled = false; }
    });

    // AS400 import
    document.getElementById('as400ImportForm')?.addEventListener('submit', async e => {
        e.preventDefault();
        const btn = document.getElementById('btn_run_import');
        const spinner = document.getElementById('import_spinner');
        const terminal = document.getElementById('as400_terminal');
        btn.disabled = true; spinner.style.display = 'inline-block'; terminal.style.display = 'block';
        terminal.textContent = 'Connecting to AS400...\n';
        try {
            const resp = await fetch('import_as400_ajax.php', { method: 'POST', body: new FormData(e.target) });
            const data = await resp.json();
            if (data.status === 'success') {
                terminal.textContent += `\n✓ ${data.message}\nImported: ${data.imported}\nUpdated: ${data.updated}\nSkipped: ${data.skipped}\n`;
                setTimeout(() => window.location.reload(), 1800);
            } else {
                terminal.textContent += `\n${data.status === 'not_found' ? '⚠️' : '❌'} ${data.message}\n`;
            }
        } catch(err) { terminal.textContent += `\n❌ ${err.message}\n`; }
        finally { btn.disabled = false; spinner.style.display = 'none'; }
    });
});
</script>
</body>
</html>
