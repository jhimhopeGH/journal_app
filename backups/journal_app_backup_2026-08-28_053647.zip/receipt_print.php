<?php
// receipt_print.php - 80mm Thermal Receipt Reprint
require_once __DIR__ . '/ej_db.php';

$id    = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$entry = getEjEntryById($id);

if (!$entry) {
    echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><link rel="stylesheet" href="style.css"></head><body>
          <div class="container"><h1>EJ Entry not found</h1>
          <a class="btn" href="receipt_reprint.php">Back to Receipt Reprint</a></div></body></html>';
    exit;
}

// Load Store Master
$storeMaster = null;
if (!empty($entry['store_code'])) {
    $smStmt = $pdo->prepare("SELECT * FROM store_master WHERE store_code = :code OR store_name = :code ORDER BY id DESC LIMIT 1");
    $smStmt->execute([':code' => $entry['store_code']]);
    $storeMaster = $smStmt->fetch(PDO::FETCH_ASSOC);
}
if (!$storeMaster) $storeMaster = getStoreMaster();

// Load Register Master
$registerRecord = null;
if (!empty($entry['store_code']) && !empty($entry['register_number'])) {
    $regStmt = $pdo->prepare("SELECT * FROM register_master WHERE store_code = :sc AND reg_no = :rn ORDER BY id DESC LIMIT 1");
    $regStmt->execute([':sc' => $entry['store_code'], ':rn' => $entry['register_number']]);
    $registerRecord = $regStmt->fetch(PDO::FETCH_ASSOC);
}

$tenderNameMap = getTenderNameMap();

// Load settings
$settingsFile = __DIR__ . '/receipt_print_settings.json';
$settings = file_exists($settingsFile) ? (json_decode(file_get_contents($settingsFile), true) ?? []) : [];
$W              = (int)($settings['char_width']        ?? 42);
$fontSize       = (float)($settings['font_size']       ?? 10);
$lineHeight     = (float)($settings['line_height']     ?? 1.3);
$paddingX       = (int)($settings['receipt_padding_x'] ?? 10);
$paddingY       = (int)($settings['receipt_padding_y'] ?? 4);
$colQtyW        = (int)($settings['col_qty_width']     ?? 4);
$colSkuW        = (int)($settings['col_sku_width']     ?? 10);
$colPriceW      = (int)($settings['col_price_width']   ?? 8);
$colAmtW        = (int)($settings['col_amt_width']     ?? 9);
$colSubLabel    = (int)($settings['col_subtotal_label']?? 26);
$colSubAmt      = (int)($settings['col_subtotal_amt']  ?? 14);
$colTotalLabel  = (int)($settings['col_total_label']   ?? 26);
$colTotalAmt    = (int)($settings['col_total_amt']     ?? 14);
$colTenderLabel = (int)($settings['col_tender_label']  ?? 26);
$colTenderAmt   = (int)($settings['col_tender_amt']    ?? 14);
$colChangeLabel = (int)($settings['col_change_label']  ?? 16);
$colChangeAmt   = (int)($settings['col_change_amt']    ?? 14);
$colVatLabel    = (int)($settings['col_vat_label']     ?? 17);
$colVatAmt      = (int)($settings['col_vat_amt']       ?? 14);

// Dates & Times
$rawDate       = $entry['entry_date'] ?? '';
$dateTimestamp = strtotime($rawDate);
$trxDateStr    = $dateTimestamp ? date('n/j/y', $dateTimestamp)  : $rawDate;
$dateLong      = $dateTimestamp ? date('F j, Y', $dateTimestamp) : $rawDate;
$rawTime       = $entry['entry_time'] ?? '';
$timeFormatted = $rawTime ? date('H:i', strtotime($rawTime)) : '';

// Ensure SKU descriptions
ensureEntryItemDescriptions($entry);

$decodedItems   = json_decode($entry['items']   ?? '[]', true);
if (!is_array($decodedItems))   $decodedItems   = [];
$decodedTenders = json_decode($entry['tenders'] ?? '[]', true);
if (!is_array($decodedTenders)) $decodedTenders = [];

// Financials
$subtotal    = (float)($entry['subtotal']      ?? 0);
$vatableSales= (float)($entry['vatable_sales'] ?? 0);
$totalVat    = (float)($entry['total_vat']     ?? 0);
$totalNonVat = (float)($entry['total_non_vat'] ?? 0);
$totalAmount = (float)($entry['total_amount']  ?? 0);
$vatRate     = (float)($entry['vat_rate']      ?? 12.0);
if ($vatRate <= 0) $vatRate = 12.0;

if ($subtotal <= 0 && !empty($decodedItems))
    $subtotal = array_sum(array_map(fn($i) => (float)($i['amount'] ?? 0), $decodedItems));
if ($totalAmount <= 0) $totalAmount = $subtotal;

if ($vatableSales <= 0 && $totalVat <= 0 && $totalAmount > 0) {
    $vatableBase  = max(0, $totalAmount - $totalNonVat);
    $vatableSales = round($vatableBase / (1 + ($vatRate / 100)), 2);
    $totalVat     = round($vatableBase - $vatableSales, 2);
}

// Tenders: separate positive from negative (negative = change stored as tender)
$positiveTenders   = [];
$negativeChangeSum = 0;
foreach ($decodedTenders as $t) {
    $tAmt = (float)($t['amount'] ?? 0);
    if ($tAmt < 0) $negativeChangeSum += abs($tAmt);
    else            $positiveTenders[] = $t;
}
// CASH last
usort($positiveTenders, function($a, $b) {
    $aIsCash = strtolower(trim($a['name'] ?? '')) === 'cash';
    $bIsCash = strtolower(trim($b['name'] ?? '')) === 'cash';
    return $aIsCash === $bIsCash ? 0 : ($aIsCash ? 1 : -1);
});
$totalTendered = array_sum(array_map(fn($t) => (float)($t['amount'] ?? 0), $positiveTenders));
if (empty($decodedTenders)) $totalTendered = $totalAmount;
$change = ($negativeChangeSum > 0) ? $negativeChangeSum : max(0, $totalTendered - $totalAmount);

// Invoice / Trx
$invoiceFormatted     = !empty($entry['invoice_number']) ? str_pad(ltrim($entry['invoice_number'], '0'), 8, '0', STR_PAD_LEFT) : '00000000';
$rawTrx               = preg_replace('/[^\d]/', '', (string)$entry['transaction_number']);
$storeCode            = trim($entry['store_code']      ?? '');
$regNo                = trim($entry['register_number'] ?? '');
$tillNo               = trim($entry['till_number']     ?? '0000');
$totalQty             = array_sum(array_map(fn($i) => (int)abs((float)($i['quantity'] ?? 1)), $decodedItems));

// FP number from register master
$fpNumber   = trim($registerRecord['permit_number'] ?? '');
$serialNum  = trim($registerRecord['serial_number'] ?? ($storeMaster['serial_number'] ?? ''));
$minNum     = trim($registerRecord['min_number']    ?? ($storeMaster['min_number']    ?? ''));

// Cashier
$salesAssoc = trim($entry['sales_associate'] ?? '');
$assocId    = trim($entry['associate_id']    ?? '');
if ($assocId === '' && ctype_digit($salesAssoc)) { $assocId = $salesAssoc; $salesAssoc = ''; }
if ($salesAssoc === '' && $assocId !== '') $cashierDisplay = $assocId;
else $cashierDisplay = $salesAssoc;

// Build lines
$divAster = str_repeat('*', $W);
$divDash  = str_repeat('-', $W);
$divDbl   = str_repeat('=', $W);

function rcPad($str, $width) {
    $len = strlen($str);
    if ($len >= $width) return substr($str, 0, $width);
    $l = (int)(($width - $len) / 2);
    return str_repeat(' ', $l) . $str . str_repeat(' ', $width - $len - $l);
}

$lines = [];

// Header
$lines[] = $divAster;
if ($storeMaster) {
    $hText = trim($storeMaster['header'] ?? '');
    if ($hText !== '') {
        foreach (preg_split('/\r\n|\r|\n/', $hText) as $hl) {
            $trimmed = trim($hl);
            if ($trimmed !== '') $lines[] = rcPad($trimmed, $W);
        }
    } elseif (!empty($storeMaster['store_name'])) {
        $lines[] = rcPad(trim($storeMaster['store_name']), $W);
    }
    if (!empty($serialNum)) $lines[] = rcPad('SERIAL#' . $serialNum, $W);
    if (!empty($minNum))    $lines[] = rcPad('MIN' . $minNum, $W);
}
$lines[] = $divAster;
$lines[] = '';
$lines[] = rcPad('*** R E P R I N T ***', $W);
$lines[] = rcPad('*** R E P R I N T ***', $W);
$lines[] = '';

// Customer
$memberNo = trim($entry['member_number'] ?? ''); if ($memberNo === '0') $memberNo = '';
$custName = trim($entry['customer_name'] ?? ''); if ($custName === '0') $custName = '';
$custAddr = trim($entry['customer_address'] ?? ''); if ($custAddr === '0') $custAddr = '';
$custTin  = trim($entry['customer_tin']  ?? ''); if ($custTin  === '0') $custTin  = '';
$lines[] = 'Member # : ' . $memberNo;
$lines[] = 'Name     : ' . $custName;
$lines[] = 'Address  : ' . $custAddr;
$lines[] = 'TIN      : ' . $custTin;
$lines[] = '';

// Items header
$lines[] = str_pad('QTY', $colQtyW, ' ', STR_PAD_LEFT)
         . '  ' . str_pad('ITEM', $colSkuW, ' ', STR_PAD_RIGHT)
         . '  ' . str_pad('PRICE', $colPriceW, ' ', STR_PAD_LEFT)
         . '  ' . str_pad('TOTAL', $colAmtW, ' ', STR_PAD_LEFT);
$lines[] = str_pad(str_repeat('-', min($colQtyW, 3)), $colQtyW, ' ', STR_PAD_LEFT)
         . '  ' . str_pad(str_repeat('-', min($colSkuW, 5)), $colSkuW, ' ', STR_PAD_RIGHT)
         . '  ' . str_pad(str_repeat('-', min($colPriceW, 5)), $colPriceW, ' ', STR_PAD_LEFT)
         . '  ' . str_pad(str_repeat('-', min($colAmtW, 5)), $colAmtW, ' ', STR_PAD_LEFT);

foreach ($decodedItems as $itm) {
    $qty    = (float)($itm['quantity']  ?? 1);
    $amt    = (float)($itm['amount']    ?? 0);
    $uPrice = (float)($itm['unit_price'] ?? ($qty > 0 ? $amt / $qty : $amt));
    $skuRaw = str_pad(trim($itm['sku'] ?? ''), 9, '0', STR_PAD_LEFT);
    $desc   = mb_substr(trim($itm['description'] ?? ''), 0, $W - 4);
    $amtV   = number_format($amt, 2, '.', ',') . 'V';

    $lines[] = str_pad((int)$qty, $colQtyW, ' ', STR_PAD_LEFT)
             . '  ' . str_pad($skuRaw, $colSkuW, ' ', STR_PAD_RIGHT)
             . '  ' . str_pad(number_format($uPrice, 2, '.', ','), $colPriceW, ' ', STR_PAD_LEFT)
             . '  ' . str_pad($amtV, $colAmtW, ' ', STR_PAD_LEFT);
    $lines[] = '     ' . $desc;
}

// Totals
$lines[] = str_pad('Sub Total', $colSubLabel, ' ', STR_PAD_LEFT) . str_pad('P' . number_format($subtotal, 2, '.', ','), $colSubAmt, ' ', STR_PAD_LEFT);
$lines[] = str_pad('Total',     $colTotalLabel,' ', STR_PAD_LEFT) . str_pad('P' . number_format($totalAmount, 2, '.', ','), $colTotalAmt, ' ', STR_PAD_LEFT);

// Tenders
if (empty($positiveTenders)) {
    $lines[] = str_pad('Cash', $colTenderLabel, ' ', STR_PAD_LEFT) . str_pad('P' . number_format($totalAmount, 2, '.', ','), $colTenderAmt, ' ', STR_PAD_LEFT);
} else {
    foreach ($positiveTenders as $t) {
        $tName = trim($t['name'] ?? 'Cash');
        $tName = $tenderNameMap[strtolower($tName)] ?? $tName;
        $tAmt  = (float)($t['amount'] ?? 0);
        $lines[] = str_pad($tName, $colTenderLabel, ' ', STR_PAD_LEFT) . str_pad('P' . number_format($tAmt, 2, '.', ','), $colTenderAmt, ' ', STR_PAD_LEFT);
    }
}

// Change with arrow
$changeFormatted = ($change > 0) ? 'P-' . number_format($change, 2, '.', ',') : 'P' . number_format(abs($change), 2, '.', ',');
$lines[] = str_pad('CHANGE', $colChangeLabel, ' ', STR_PAD_LEFT) . '  ====>' . str_pad($changeFormatted, $colChangeAmt, ' ', STR_PAD_LEFT);

// VAT Breakdown
$vatExempt   = 0.0;
$zeroRated   = 0.0;
$lines[] = str_pad('VATable Sales  :', $colVatLabel, ' ', STR_PAD_RIGHT) . str_pad('P' . number_format($vatableSales, 2, '.', ','), $colVatAmt, ' ', STR_PAD_LEFT);
$lines[] = str_pad('VAT            :', $colVatLabel, ' ', STR_PAD_RIGHT) . str_pad('P' . number_format($totalVat, 2, '.', ','),     $colVatAmt, ' ', STR_PAD_LEFT);
$lines[] = str_pad('VAT Exempt Sale:', $colVatLabel, ' ', STR_PAD_RIGHT) . str_pad('P' . number_format($vatExempt, 2, '.', ','),    $colVatAmt, ' ', STR_PAD_LEFT);
$lines[] = str_pad('Zero Rated Sale:', $colVatLabel, ' ', STR_PAD_RIGHT) . str_pad('P' . number_format($zeroRated, 2, '.', ','),    $colVatAmt, ' ', STR_PAD_LEFT);
$lines[] = 'Cashier: ' . $cashierDisplay;

// Dash divider before footer
$lines[] = $divDash;

// Store Footer
$footerText = trim($storeMaster['footer'] ?? '');
if ($footerText !== '') {
    foreach (preg_split('/\r\n|\r|\n/', $footerText) as $fl) {
        $trimmed = trim($fl);
        if ($trimmed !== '') $lines[] = $trimmed;
    }
}

// Double divider
$lines[] = $divDbl;

// Transaction summary
$lines[] = "T#{$rawTrx} S{$storeCode} Reg{$regNo}/{$tillNo} {$trxDateStr} {$timeFormatted}";
$lines[] = 'Invoice #: ' . $invoiceFormatted . str_repeat(' ', 4) . "TQty:==>   {$totalQty}";

// Store company info from header second lines / store_name
if ($storeMaster) {
    $hLines = preg_split('/\r\n|\r|\n/', trim($storeMaster['header'] ?? ''));
    foreach ($hLines as $hl) {
        $t = trim($hl);
        if ($t !== '') $lines[] = $t;
    }
}

// FP / permit number
if (!empty($fpNumber)) $lines[] = $fpNumber;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Receipt Reprint - Trx #<?php echo htmlspecialchars($entry['transaction_number']); ?></title>
<link rel="stylesheet" href="style.css">
<style>
  @page { size: 80mm auto; margin: 0; }
  * { box-sizing: border-box; }
  body {
      font-family: Arial, Helvetica, sans-serif;
      background: #f1f5f9;
      margin: 0; padding: 0;
  }
  .controls-bar {
      position: sticky; top: 0;
      background: #4c1d95;
      color: #fff;
      padding: 10px 20px;
      display: flex; gap: 12px; align-items: center;
      box-shadow: 0 4px 12px rgba(0,0,0,0.2);
      z-index: 1000;
  }
  .controls-bar a, .controls-bar button {
      background: #7c3aed; color: #fff; border: none;
      padding: 7px 16px; border-radius: 5px; font-weight: 600;
      cursor: pointer; text-decoration: none; font-size: 13px;
      display: inline-flex; align-items: center; gap: 6px;
      transition: background 0.15s;
  }
  .controls-bar a:hover, .controls-bar button:hover { background: #6d28d9; }
  .controls-bar button.btn-print { background: #059669; font-size: 14px; padding: 8px 20px; }
  .controls-bar button.btn-print:hover { background: #047857; }
  .controls-bar a.btn-back { background: #475569; }
  .controls-bar a.btn-back:hover { background: #334155; }
  .page-viewport { padding: 24px 15px 60px; display: flex; flex-direction: column; align-items: center; gap: 20px; }
  .receipt-sheet {
      width: 80mm;
      background: #fff;
      border: 1px solid #cbd5e1;
      border-radius: 2px;
      box-shadow: 0 8px 28px rgba(0,0,0,0.12);
      padding: 6px 0;
  }
  .receipt-info-badge {
      font-family: system-ui, sans-serif; font-size: 12px; font-weight: 600;
      color: #6d28d9; background: #ede9fe;
      padding: 4px 12px; border-radius: 12px;
  }
  pre.receipt-content {
      font-family: 'Courier New', Courier, 'Lucida Console', monospace;
      font-size: <?php echo $fontSize; ?>px;
      line-height: <?php echo $lineHeight; ?>;
      color: #000;
      margin: 0;
      padding: <?php echo $paddingY; ?>px <?php echo $paddingX; ?>px;
      white-space: pre;
      overflow-x: hidden;
  }
  @media print {
      @page { size: 80mm auto; margin: 0; }
      html, body { background: #fff !important; margin: 0 !important; padding: 0 !important; }
      .controls-bar, .page-viewport > .receipt-info-badge { display: none !important; }
      .page-viewport { padding: 0 !important; display: block !important; }
      .receipt-sheet { width: 80mm !important; border: none !important; box-shadow: none !important; border-radius: 0 !important; padding: 0 !important; }
      pre.receipt-content { font-size: <?php echo ($fontSize * 0.82); ?>pt !important; }
  }
</style>
</head>
<body>
<div class="controls-bar">
    <button class="btn-print" onclick="window.print()">🖨️ Print Receipt</button>
    <a class="btn-back" href="receipt_reprint.php">← Back to Receipt Reprint</a>
    <a href="ej_entry.php?id=<?php echo (int)$entry['id']; ?>" style="background:#334155;">✏️ Edit Entry</a>
</div>

<div class="page-viewport">
    <div class="receipt-info-badge">🧾 80mm Thermal Receipt | Trx #<?php echo htmlspecialchars($entry['transaction_number']); ?> | Store <?php echo htmlspecialchars($storeCode); ?></div>
    <div class="receipt-sheet">
        <pre class="receipt-content"><?php echo htmlspecialchars(implode("\n", $lines)); ?></pre>
    </div>
</div>
</body>
</html>
