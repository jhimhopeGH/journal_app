import sys
import os
import json
import datetime
import sqlite3
import pyodbc

# Base date for Clarion standard
CLARION_BASE = datetime.date(1800, 12, 28)

def clarion_to_date_str(val):
    try:
        val_int = int(val)
        if val_int <= 0:
            return ""
        d = CLARION_BASE + datetime.timedelta(days=val_int)
        return d.strftime("%Y-%m-%d")
    except Exception:
        return ""

def import_tps(store_code, dsn_name="Salessum", db_path=None):
    if not db_path:
        db_path = os.path.join(os.path.dirname(__file__), "..", "journal.db")
        db_path = os.path.abspath(db_path)

    if not store_code:
        return {"status": "error", "message": "Store code is required."}

    # Connect to SQLite
    sqlite_conn = sqlite3.connect(db_path)
    sqlite_cur = sqlite_conn.cursor()

    # Connect to TopSpeed ODBC
    try:
        tps_conn = pyodbc.connect(f"DSN={dsn_name}", autocommit=True)
        tps_cur = tps_conn.cursor()
    except Exception as e:
        return {"status": "error", "message": f"Failed to connect to TopSpeed ODBC ({dsn_name}): {str(e)}"}

    try:
        tps_cur.execute("SELECT * FROM SALESUMM")
        col_names = [desc[0].upper() for desc in tps_cur.description]
        rows = tps_cur.fetchall()
    except Exception as e:
        tps_conn.close()
        sqlite_conn.close()
        return {"status": "error", "message": f"Failed to read SALESUMM table: {str(e)}"}

    imported_count = 0
    skipped_count = 0
    updated_count = 0

    # Read existing entries to prevent duplicate insertion
    # (Checking store_number, register_number, entry_date, zread_number)
    sqlite_cur.execute("SELECT id, store_number, register_number, entry_date, zread_number FROM entries")
    existing_map = {}
    for r in sqlite_cur.fetchall():
        key = (str(r[1]).strip(), str(r[2]).strip(), str(r[3]).strip(), str(r[4]).strip())
        existing_map[key] = r[0]

    # Build tender column mapping using tender_master for canonical names.
    # TPS has fixed bucket columns; we map them to display names from tender_master.
    # Fallback names are used if a name isn't found in tender_master.
    sqlite_cur.execute("SELECT tender_name FROM tender_master ORDER BY id")
    tm_names = {r[0].strip().lower(): r[0].strip() for r in sqlite_cur.fetchall()}

    def resolve_tender(raw_name):
        return tm_names.get(raw_name.strip().lower(), raw_name)

    # (fallback_name, TPS_column)
    tender_col_map = [
        (resolve_tender("Cash"),                "CASH"),
        (resolve_tender("Check"),               "CHEQUE"),
        (resolve_tender("BPI"),                 "CARD"),    # TPS "Card" bucket -> BPI
        (resolve_tender("Gift Cert Redeem"),    "GC"),      # TPS "GC" bucket -> Gift Cert Redeem (TND-005)
        (resolve_tender("House Account Charge"), "AR"),     # TPS "AR" bucket -> House Account Charge (TND-002)
        (resolve_tender("RNB CARD"),            "OTHERS"),  # TPS "Others" bucket -> RNB CARD
    ]

    for row in rows:
        r_dict = dict(zip(col_names, row))

        entry_date = clarion_to_date_str(r_dict.get("DATE", 0))
        if not entry_date:
            skipped_count += 1
            continue

        reg_no = str(r_dict.get("REG_NO", "") or "").strip()
        if reg_no == "0" or reg_no == "":
            skipped_count += 1
            continue
        
        # Reset counter / Z-Read number
        rc = r_dict.get("RC", 0)
        zread_no = str(int(float(rc))) if rc is not None else "0"

        # Last trx # is CURRRTX_NO from TPS file
        last_trx = str(r_dict.get("CURRRTX_NO", "") or "").strip()
        trx_no = last_trx  # Keep transaction_number aligned

        # Sales & Totals (DISCOUNT, REFUND, VOID are excluded)
        daily_sales = float(r_dict.get("SALES", 0.0) or 0.0)
        vat_sales = float(r_dict.get("VATSALESX", 0.0) or 0.0)
        non_vat_sales = float(r_dict.get("NONVATSALESX", 0.0) or 0.0)
        old_gt = float(r_dict.get("PREVGRANDTOTALX", 0.0) or 0.0)
        new_gt = float(r_dict.get("CURRGRANDTOTALX", 0.0) or 0.0)

        # Build tender breakdown using TPS bucket columns mapped to canonical names
        tenders = []
        for t_name, t_col in tender_col_map:
            val = float(r_dict.get(t_col, 0.0) or 0.0)
            if val > 0:
                tenders.append({"name": t_name, "amount": val})

        tender_json = json.dumps(tenders)

        # Check duplicate
        dup_key = (store_code.strip(), reg_no, entry_date, zread_no)
        if dup_key in existing_map:
            # Update existing
            entry_id = existing_map[dup_key]
            sqlite_cur.execute("""
                UPDATE entries SET
                    transaction_number = ?,
                    last_trx_number = ?,
                    tender = ?,
                    total_vat = ?,
                    total_non_vat = ?,
                    daily_sales = ?,
                    old_grand_total = ?,
                    new_grand_total = ?
                WHERE id = ?
            """, (
                trx_no, last_trx, tender_json,
                vat_sales, non_vat_sales, daily_sales, old_gt, new_gt,
                entry_id
            ))
            updated_count += 1
        else:
            # Insert new record
            sqlite_cur.execute("""
                INSERT INTO entries (
                    store_number, register_number, transaction_number,
                    entry_date, entry_time, zread_number, till_number,
                    last_trx_number, tender, total_vat, total_non_vat,
                    daily_sales, old_grand_total, new_grand_total
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                store_code.strip(), reg_no, trx_no,
                entry_date, "00:00:00", zread_no, "1",
                last_trx, tender_json, vat_sales, non_vat_sales,
                daily_sales, old_gt, new_gt
            ))
            imported_count += 1

    # After import/update, recalculate any entries where daily_sales or old_grand_total is 0
    recalc_count = recalculate_grand_totals(sqlite_cur, store_code)
    sqlite_conn.commit()
    tps_conn.close()
    sqlite_conn.close()

    return {
        "status": "success",
        "total_read": len(rows),
        "imported": imported_count,
        "updated": updated_count,
        "recalculated": recalc_count,
        "store_code": store_code
    }


def recalculate_grand_totals(cur, store_code=None):
    """
    Fix entries where:
    1. daily_sales = 0 but total_vat + total_non_vat > 0  -> set daily_sales = total_vat + total_non_vat
    2. old_grand_total = 0 and zread_number > 1           -> fill from previous z-read's new_grand_total
       (matched by store_number + register_number, ordered by zread_number)

    Returns the count of rows updated.
    """
    updated = 0

    # Step 1: Fix daily_sales where it's 0 but VAT/NonVAT data exists
    if store_code:
        cur.execute("""
            UPDATE entries
            SET daily_sales = total_vat + total_non_vat
            WHERE store_number = ?
              AND daily_sales = 0
              AND (total_vat > 0 OR total_non_vat > 0)
        """, (store_code,))
    else:
        cur.execute("""
            UPDATE entries
            SET daily_sales = total_vat + total_non_vat
            WHERE daily_sales = 0
              AND (total_vat > 0 OR total_non_vat > 0)
        """)
    updated += cur.rowcount

    # Step 2: Fix old_grand_total = 0 for entries where zread > 1
    # For each affected row, find the previous z-read (same store+register, lower zread number)
    # and use its new_grand_total as the old_grand_total.
    if store_code:
        cur.execute("""
            SELECT id, store_number, register_number, CAST(zread_number AS INTEGER) AS zread_int
            FROM entries
            WHERE store_number = ?
              AND old_grand_total = 0
              AND CAST(zread_number AS INTEGER) > 1
            ORDER BY store_number, register_number, zread_int
        """, (store_code,))
    else:
        cur.execute("""
            SELECT id, store_number, register_number, CAST(zread_number AS INTEGER) AS zread_int
            FROM entries
            WHERE old_grand_total = 0
              AND CAST(zread_number AS INTEGER) > 1
            ORDER BY store_number, register_number, zread_int
        """)

    affected = cur.fetchall()
    for row_id, store_num, reg_num, zread_int in affected:
        # Find the immediately preceding z-read for this store+register
        cur.execute("""
            SELECT new_grand_total
            FROM entries
            WHERE store_number = ?
              AND register_number = ?
              AND CAST(zread_number AS INTEGER) < ?
            ORDER BY CAST(zread_number AS INTEGER) DESC
            LIMIT 1
        """, (store_num, reg_num, zread_int))
        prev = cur.fetchone()
        if prev and prev[0] and prev[0] > 0:
            prev_new_gt = prev[0]
            # Also fix new_grand_total if it was correctly set; otherwise recompute
            cur.execute("""
                SELECT daily_sales, new_grand_total FROM entries WHERE id = ?
            """, (row_id,))
            entry = cur.fetchone()
            if entry:
                daily = entry[0]
                new_gt = entry[1] if entry[1] > 0 else prev_new_gt + daily
                cur.execute("""
                    UPDATE entries
                    SET old_grand_total = ?,
                        new_grand_total = ?
                    WHERE id = ?
                """, (prev_new_gt, new_gt, row_id))
                updated += cur.rowcount

    return updated

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(json.dumps({"status": "error", "message": "Store code argument missing."}))
        sys.exit(1)

    store_arg = sys.argv[1]
    dsn_arg = sys.argv[2] if len(sys.argv) > 2 else "Salessum"
    db_arg = sys.argv[3] if len(sys.argv) > 3 else None

    res = import_tps(store_arg, dsn_arg, db_arg)
    print(json.dumps(res))
