<?php
// partials/nav.php
// Include this after setting $currentPage in the calling file.
// $currentPage values used: 'dashboard', 'journal', 'ej', 'admin', 'users', etc.
if (!isset($currentPage)) {
    $currentPage = '';
}

require_once __DIR__ . '/../auth.php';

$navUser = getCurrentUser();
$isNavAdmin = isAdmin();

function navClass($page, $current) {
    return 'nav-link' . ($page === $current ? ' active' : '');
}
?>
<aside class="sidebar">
    <div class="sidebar-brand">
        <span class="brand-mark">EJ</span>
        <span class="brand-text">Electronic Journal</span>
    </div>

    <nav class="sidebar-nav">
        <div class="nav-group-label">
            <span class="nav-icon">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
            </span>
            Main
        </div>
        <a class="<?php echo navClass('dashboard', $currentPage); ?> nav-sublink" href="dashboard.php">
            Dashboard
        </a>

        <div class="nav-group-label">
            <span class="nav-icon">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 6 2 18 2 18 9"></polyline><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path><rect x="6" y="14" width="12" height="8"></rect></svg>
            </span>
            Reprint
        </div>
        <a class="<?php echo navClass('journal', $currentPage); ?> nav-sublink" href="records.php">Zread Reprint</a>
        <a class="<?php echo navClass('ej', $currentPage); ?> nav-sublink" href="ej_printing.php">EJ Printing</a>
        <a class="<?php echo navClass('receipt_reprint', $currentPage); ?> nav-sublink" href="receipt_reprint.php">Receipt Reprint</a>

        <?php if ($isNavAdmin): ?>
            <div class="nav-group-label">
                <span class="nav-icon">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>
                </span>
                Admin
            </div>
            <a class="<?php echo navClass('users', $currentPage); ?> nav-sublink" href="users.php">
                User Management
            </a>
            <a class="<?php echo navClass('admin', $currentPage); ?> nav-sublink" href="admin.php">
                Database
            </a>
            <a class="<?php echo navClass('store_master', $currentPage); ?> nav-sublink" href="store_master.php">
                Store Master
            </a>
            <a class="<?php echo navClass('register_master', $currentPage); ?> nav-sublink" href="register_master.php">
                Register Master
            </a>
            <a class="<?php echo navClass('tender_master', $currentPage); ?> nav-sublink" href="tender_master.php">
                Tender Master
            </a>
            <a class="<?php echo navClass('layout', $currentPage); ?> nav-sublink" href="print_layout.php">
                Zread Print Layout
            </a>
            <a class="<?php echo navClass('ej_layout', $currentPage); ?> nav-sublink" href="ej_print_layout.php">
                EJ Print Layout
            </a>
            <a class="<?php echo navClass('receipt_layout', $currentPage); ?> nav-sublink" href="receipt_print_layout.php">
                Receipt Print Layout
            </a>
        <?php endif; ?>
    </nav>

    <!-- User Profile & Logout Widget -->
    <?php if ($navUser): ?>
        <div style="margin-top: auto; padding: 14px 18px 0; border-top: 1px solid rgba(255,255,255,0.08); display: flex; align-items: center; justify-content: space-between; gap: 8px;">
            <div style="display: flex; align-items: center; gap: 9px; overflow: hidden;">
                <div style="width: 32px; height: 32px; border-radius: 50%; background: linear-gradient(135deg, #7c3aed, #4f46e5); color: #fff; display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 13px; flex-shrink: 0; box-shadow: 0 2px 6px rgba(0,0,0,0.3);">
                    <?php echo strtoupper(substr($navUser['username'] ?? 'U', 0, 1)); ?>
                </div>
                <div style="overflow: hidden; line-height: 1.25;">
                    <div style="font-size: 12px; font-weight: 700; color: #f8fafc; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                        <?php echo htmlspecialchars($navUser['username'] ?? 'User'); ?>
                    </div>
                    <div style="font-size: 10px; font-weight: 600; color: <?php echo $isNavAdmin ? '#c084fc' : '#94a3b8'; ?>; text-transform: uppercase; letter-spacing: 0.5px;">
                        <?php echo htmlspecialchars($navUser['role'] ?? 'user'); ?>
                    </div>
                </div>
            </div>
            <a href="logout.php" title="Sign Out" onclick="return confirm('Are you sure you want to log out?');" style="color: #f87171; background: rgba(239, 68, 68, 0.12); border-radius: 12px; padding: 6px 10px; font-size: 12px; text-decoration: none; display: inline-flex; align-items: center; gap: 4px; font-weight: 700; transition: all 0.15s ease;">
                <span>Logout</span>
            </a>
        </div>
    <?php endif; ?>
</aside>
