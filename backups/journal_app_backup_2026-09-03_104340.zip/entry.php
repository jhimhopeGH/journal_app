<?php
// entry.php - New / Edit journal entry input form
require_once __DIR__ . '/auth.php';
requireLogin();
require_once __DIR__ . '/db.php';
$today = date('Y-m-d');


// Load all tenders for dropdown (ordered by name ascending for usability)
$tenders = getAllTenderMasters();
usort($tenders, fn($a, $b) => strcmp($a['tender_name'], $b['tender_name']));

// If editing, load existing record
$editId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$entry = [
    'store_number'      => '',
    'register_number'   => '',
    'entry_date'        => $today,
    'zread_number'      => '',
    'till_number'       => '',
    'last_trx_number'   => '',
    'tender'            => '',
    'total_vat'         => '0.00',
    'total_non_vat'     => '0.00',
    'daily_sales'       => '0.00',
    'old_grand_total'   => '0.00',
    'new_grand_total'   => '0.00',
    'entry_time'        => date('H:i')
];

if ($editId > 0) {
    $stmt = $pdo->prepare("SELECT * FROM entries WHERE id = :id");
    $stmt->execute([':id' => $editId]);
    $existing = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($existing) {
        $entry = $existing;
        if (preg_match('/^\d{2}\/\d{2}\/\d{2}$/', $entry['entry_date'])) {
            $dateObj = DateTime::createFromFormat('m/d/y', $entry['entry_date']);
            if ($dateObj) {
                $entry['entry_date'] = $dateObj->format('Y-m-d');
            }
        }
        // Ensure daily_sales is the exact sum of VAT + Non-VAT
        $entry['daily_sales'] = number_format((float)$entry['total_vat'] + (float)$entry['total_non_vat'], 2, '.', '');
        $entry['new_grand_total'] = number_format((float)$entry['old_grand_total'] + (float)$entry['daily_sales'], 2, '.', '');
    }
}

$isEdit = $editId > 0 && isset($existing) && $existing;
$pageTitle = $isEdit ? 'Edit Journal Entry' : 'New Journal Entry';

// Decode existing tender JSON for edit pre-population
$existingTenders = [];
if ($entry['tender'] !== '') {
    $decoded = json_decode($entry['tender'], true);
    if (is_array($decoded)) {
        $existingTenders = $decoded;
    } else {
        $existingTenders = [['name' => $entry['tender'], 'amount' => '']];
    }
}
if (empty($existingTenders)) {
    $existingTenders = [['name' => '', 'amount' => '']];
}

// Build the tender options HTML once (reused in JS template)
$tenderOptionsHtml = '<option value="">-- Select Tender --</option>';
foreach ($tenders as $t) {
    $tenderOptionsHtml .= '<option value="' . htmlspecialchars($t['tender_name']) . '">' .
        htmlspecialchars($t['tender_name']) . ' (' . htmlspecialchars($t['tender_code']) . ')' .
        '</option>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title><?php echo $pageTitle; ?> - Electronic Journal</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="app-shell">
    <?php $currentPage = 'journal'; require __DIR__ . '/partials/nav.php'; ?>

    <main class="main-content">
        <div class="top-nav">
            <a href="entry.php">+ New Entry</a>
            <a href="records.php">View Records</a>
        </div>

        <div class="page-header">
            <h1><?php echo $pageTitle; ?></h1>
            <p>Fill in the transaction details below and save.</p>
        </div>

        <form method="post" action="save.php" id="journalForm">
            <input type="hidden" name="edit_id" value="<?php echo $editId; ?>">
            <input type="hidden" name="till_number" value="<?php echo htmlspecialchars($entry['till_number'] !== '' ? $entry['till_number'] : '0000'); ?>">

            <div class="form-grid" style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px; margin-bottom: 24px;">
                
                <!-- Left panel: Transaction Details -->
                <div class="panel">
                    <h2>Transaction Details</h2>
                    <div style="display: flex; flex-direction: column; gap: 14px;">
                        <div>
                            <label for="store_number" style="margin-top: 0;">Store</label>
                            <input type="text" id="store_number" name="store_number" value="<?php echo htmlspecialchars($entry['store_number']); ?>" required>
                        </div>
                        <div>
                            <label for="register_number" style="margin-top: 0;">Reg</label>
                            <input type="text" id="register_number" name="register_number" value="<?php echo htmlspecialchars($entry['register_number']); ?>" required>
                        </div>
                        <div>
                            <label for="entry_date" style="margin-top: 0;">Date</label>
                            <input type="date" id="entry_date" name="entry_date" value="<?php echo htmlspecialchars($entry['entry_date']); ?>" required>
                        </div>
                        <div>
                            <label for="entry_time" style="margin-top: 0;">Time</label>
                            <input type="time" id="entry_time" name="entry_time" value="<?php echo htmlspecialchars($entry['entry_time']); ?>" required>
                        </div>
                        <div>
                            <label for="last_trx_number" style="margin-top: 0;">Last Trx #</label>
                            <input type="text" id="last_trx_number" name="last_trx_number" value="<?php echo htmlspecialchars($entry['last_trx_number']); ?>" required>
                        </div>
                        <div>
                            <label for="zread_number" style="margin-top: 0;">Z No.</label>
                            <input type="text" id="zread_number" name="zread_number" value="<?php echo htmlspecialchars($entry['zread_number']); ?>" required>
                        </div>
                    </div>
                </div>

                <!-- Right panel: Financial Values -->
                <div class="panel">
                    <h2>Financials</h2>
                    <div style="display: flex; flex-direction: column; gap: 14px;">
                        <div>
                            <label for="old_grand_total" style="margin-top: 0;">Old Grand Total</label>
                            <input type="text" inputmode="decimal" id="old_grand_total" name="old_grand_total" value="<?php echo number_format((float)$entry['old_grand_total'], 2); ?>" required style="text-align: right; font-weight: 500;">
                        </div>
                        <div>
                            <label for="total_vat" style="margin-top: 0;">Total VAT</label>
                            <input type="text" inputmode="decimal" id="total_vat" name="total_vat" value="<?php echo number_format((float)$entry['total_vat'], 2); ?>" required style="text-align: right; font-weight: 500;">
                        </div>
                        <div>
                            <label for="total_non_vat" style="margin-top: 0;">Total Non-VAT</label>
                            <input type="text" inputmode="decimal" id="total_non_vat" name="total_non_vat" value="<?php echo number_format((float)$entry['total_non_vat'], 2); ?>" required style="text-align: right; font-weight: 500;">
                        </div>
                        <div>
                            <label for="daily_sales" style="margin-top: 0; display: flex; justify-content: space-between; align-items: center;">
                                <span>Daily Sales</span>
                                <span style="font-size: 11px; font-weight: normal; color: #0284c7; background: #e0f2fe; padding: 2px 6px; border-radius: 4px;">VAT + Non-VAT</span>
                            </label>
                            <input type="text" id="daily_sales" name="daily_sales" value="<?php echo number_format((float)$entry['daily_sales'], 2); ?>" readonly tabindex="-1" style="background: #f8fafc; color: #0f172a; font-weight: bold; text-align: right; border-color: #cbd5e1; cursor: not-allowed;">
                        </div>
                        <div>
                            <label for="new_grand_total" style="margin-top: 0; display: flex; justify-content: space-between; align-items: center;">
                                <span>New Grand Total</span>
                                <span style="font-size: 11px; font-weight: normal; color: #0284c7; background: #e0f2fe; padding: 2px 6px; border-radius: 4px;">Old + Daily Sales</span>
                            </label>
                            <input type="text" id="new_grand_total" name="new_grand_total" value="<?php echo number_format((float)$entry['new_grand_total'], 2); ?>" readonly tabindex="-1" style="background: #f8fafc; color: #0f172a; font-weight: bold; text-align: right; border-color: #cbd5e1; cursor: not-allowed;">
                        </div>
                        <div id="tender-balance-notice" style="margin-top: 4px; font-size: 12px; line-height: 1.4; padding: 8px 12px; border-radius: 6px; display: none;"></div>
                    </div>
                </div>
            </div>

            <!-- Bottom panel: Tender Breakdown -->
            <div class="panel" style="margin-bottom: 24px;">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <h2 style="margin: 0;">Tender Breakdown</h2>
                    <span id="tender-match-badge" style="display: none;"></span>
                </div>
                <div style="overflow-x: auto;">
                    <table style="width: 100%; border-collapse: collapse; margin-top: 10px;">
                        <thead>
                            <tr>
                                <th style="width: 60%; text-align: left; padding: 8px 10px; background: #f8fafc; border-bottom: 2px solid #e2e8f0; font-size: 13px; color: #64748b;">Tender Type</th>
                                <th style="width: 32%; text-align: right; padding: 8px 10px; background: #f8fafc; border-bottom: 2px solid #e2e8f0; font-size: 13px; color: #64748b;">Amount</th>
                                <th style="width: 8%; text-align: center; padding: 8px 10px; background: #f8fafc; border-bottom: 2px solid #e2e8f0; font-size: 13px; color: #64748b;"></th>
                            </tr>
                        </thead>
                        <tbody id="tender-body">
                            <!-- Dynamic tender rows -->
                        </tbody>
                        <tfoot>
                            <tr style="border-top: 2px solid #cbd5e1; background: #f8fafc; font-weight: bold;">
                                <td style="padding: 10px; text-align: right; color: #475569;">Total Tenders:</td>
                                <td id="total-tender-amount" style="padding: 10px; text-align: right; color: #0f172a; font-size: 14px;">₱0.00</td>
                                <td></td>
                            </tr>
                        </tfoot>
                    </table>
                <button type="button" id="add-tender-btn" class="btn btn-secondary" style="width: 100%; margin-top: 12px; background: none; border: 1px dashed #2d6cdf; color: #2d6cdf; padding: 10px; border-radius: 20px; cursor: pointer; font-weight: 600;">+ Add Tender Row</button>
            </div>

            <div style="display: flex; gap: 12px; justify-content: flex-end;">
                <a href="records.php" class="btn btn-secondary" style="margin-top: 0;">Cancel</a>
                <button type="submit" class="btn" style="margin-top: 0; background-color: #2d6cdf;">Save Entry</button>
            </div>
        </form>
    </main>
</div>

<script>
const TENDER_OPTIONS = <?php echo json_encode($tenderOptionsHtml); ?>;
const EXISTING_TENDERS = <?php echo json_encode($existingTenders); ?>;

function makeTenderRow(name = '', amount = '') {
    const tr = document.createElement('tr');
    tr.className = 'tender-row';
    
    // Unique indexing helper
    const getIndex = () => document.querySelectorAll('#tender-body .tender-row').length;
    const idx = getIndex();
    
    // Tender selection input column
    const tdSelect = document.createElement('td');
    tdSelect.style.padding = '8px 10px';
    const select = document.createElement('select');
    select.name = `tender[${idx}][name]`;
    select.required = true;
    select.innerHTML = TENDER_OPTIONS;
    if (name) select.value = name;
    tdSelect.appendChild(select);
    
    // Amount input column
    const tdAmount = document.createElement('td');
    tdAmount.style.padding = '8px 10px';
    const amountInput = document.createElement('input');
    amountInput.type = 'text';
    amountInput.inputMode = 'decimal';
    amountInput.name = `tender[${idx}][amount]`;
    amountInput.placeholder = '0.00';
    amountInput.style.textAlign = 'right';
    amountInput.style.fontWeight = '500';
    amountInput.value = amount ? formatWithCommas(parseNum(amount), 2) : '';
    
    ['input', 'change', 'keyup', 'paste'].forEach(evt => {
        amountInput.addEventListener(evt, calculateDaily);
    });
    amountInput.addEventListener('focus', function() {
        this.select();
    });
    amountInput.addEventListener('blur', function() {
        if (this.value.trim() !== '') {
            this.value = formatWithCommas(parseNum(this.value), 2);
        }
        calculateDaily();
    });
    
    tdAmount.appendChild(amountInput);
    
    // Remove button column
    const tdRemove = document.createElement('td');
    tdRemove.style.padding = '8px 10px';
    tdRemove.style.textAlign = 'center';
    const removeBtn = document.createElement('button');
    removeBtn.type = 'button';
    removeBtn.innerHTML = '✖';
    removeBtn.style.background = 'none';
    removeBtn.style.border = 'none';
    removeBtn.style.color = '#ef4444';
    removeBtn.style.cursor = 'pointer';
    removeBtn.style.fontSize = '16px';
    removeBtn.title = 'Remove Row';
    removeBtn.addEventListener('click', () => {
        if (document.querySelectorAll('#tender-body .tender-row').length > 1) {
            tr.remove();
            reindexTenders();
            calculateDaily();
        } else {
            select.value = '';
            amountInput.value = '';
            calculateDaily();
        }
    });
    tdRemove.appendChild(removeBtn);
    
    tr.appendChild(tdSelect);
    tr.appendChild(tdAmount);
    tr.appendChild(tdRemove);
    
    return tr;
}

function reindexTenders() {
    const rows = document.querySelectorAll('#tender-body .tender-row');
    rows.forEach((row, idx) => {
        const select = row.querySelector('select');
        const input = row.querySelector('input[name*="[amount]"]');
        if (select) select.name = `tender[${idx}][name]`;
        if (input) input.name = `tender[${idx}][amount]`;
    });
}

const tbody = document.getElementById('tender-body');
EXISTING_TENDERS.forEach(t => {
    tbody.appendChild(makeTenderRow(t.name || '', t.amount || ''));
});

if (tbody.children.length === 0) {
    tbody.appendChild(makeTenderRow());
}

document.getElementById('add-tender-btn').addEventListener('click', () => {
    tbody.appendChild(makeTenderRow());
    calculateDaily();
});

// Helper for parsing string with commas to float number
function parseNum(val) {
    if (val === null || val === undefined) return 0;
    const clean = val.toString().replace(/,/g, '').trim();
    return parseFloat(clean) || 0;
}

// Helper for formatting float number with standard thousands commas
function formatWithCommas(val, decimals = 2) {
    const num = parseFloat(val) || 0;
    return num.toLocaleString('en-US', {
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals
    });
}

// Dynamic calculations and validation logic
function calculateDaily() {
    const elOldGrand = document.getElementById('old_grand_total');
    const elVat = document.getElementById('total_vat');
    const elNonVat = document.getElementById('total_non_vat');
    const elDaily = document.getElementById('daily_sales');
    const elNewGrand = document.getElementById('new_grand_total');
    
    const oldGrand = parseNum(elOldGrand.value);
    const vat = parseNum(elVat.value);
    const nonVat = parseNum(elNonVat.value);
    const daily = vat + nonVat;
    const newGrand = oldGrand + daily;
    
    // Put comma-formatted numbers directly inside the textboxes
    elDaily.value = formatWithCommas(daily, 2);
    elNewGrand.value = formatWithCommas(newGrand, 2);
    
    // Calculate total sum of tenders
    let tenderSum = 0;
    document.querySelectorAll('#tender-body input[name*="[amount]"]').forEach(inp => {
        tenderSum += parseNum(inp.value);
    });
    
    const totalTenderEl = document.getElementById('total-tender-amount');
    if (totalTenderEl) {
        totalTenderEl.textContent = '₱' + formatWithCommas(tenderSum, 2);
    }
    
    const diff = Math.abs(daily - tenderSum);
    const isMismatch = diff > 0.009;
    
    const noticeEl = document.getElementById('tender-balance-notice');
    const badgeEl = document.getElementById('tender-match-badge');
    
    if (isMismatch) {
        // Turn VAT and Non-VAT textboxes RED
        elVat.style.borderColor = '#ef4444';
        elVat.style.backgroundColor = '#fef2f2';
        elVat.style.color = '#b91c1c';
        
        elNonVat.style.borderColor = '#ef4444';
        elNonVat.style.backgroundColor = '#fef2f2';
        elNonVat.style.color = '#b91c1c';
        
        if (noticeEl) {
            noticeEl.style.display = 'block';
            noticeEl.style.backgroundColor = '#fef2f2';
            noticeEl.style.color = '#b91c1c';
            noticeEl.style.border = '1px solid #fecaca';
            noticeEl.innerHTML = `⚠️ <strong>Total VAT + Non-VAT (₱${formatWithCommas(daily)})</strong> does not equal <strong>Total Tenders (₱${formatWithCommas(tenderSum)})</strong>. Difference: ₱${formatWithCommas(diff)}`;
        }
        
        if (badgeEl) {
            badgeEl.style.display = 'inline-block';
            badgeEl.style.backgroundColor = '#fee2e2';
            badgeEl.style.color = '#dc2626';
            badgeEl.style.border = '1px solid #fca5a5';
            badgeEl.style.padding = '2px 8px';
            badgeEl.style.borderRadius = '4px';
            badgeEl.style.fontSize = '11px';
            badgeEl.style.fontWeight = 'bold';
            badgeEl.textContent = '⚠️ Does not match VAT + Non-VAT';
        }
    } else {
        // Restore standard styling
        elVat.style.borderColor = '#cbd5e1';
        elVat.style.backgroundColor = '#ffffff';
        elVat.style.color = 'inherit';
        
        elNonVat.style.borderColor = '#cbd5e1';
        elNonVat.style.backgroundColor = '#ffffff';
        elNonVat.style.color = 'inherit';
        
        if (noticeEl) {
            noticeEl.style.display = 'block';
            noticeEl.style.backgroundColor = '#f0fdf4';
            noticeEl.style.color = '#15803d';
            noticeEl.style.border = '1px solid #bbf7d0';
            noticeEl.innerHTML = `✓ <strong>Balanced:</strong> Total Tenders (₱${formatWithCommas(tenderSum)}) equals Total VAT + Non-VAT (₱${formatWithCommas(daily)})`;
        }
        
        if (badgeEl) {
            badgeEl.style.display = 'inline-block';
            badgeEl.style.backgroundColor = '#dcfce7';
            badgeEl.style.color = '#16a34a';
            badgeEl.style.border = '1px solid #86efac';
            badgeEl.style.padding = '2px 8px';
            badgeEl.style.borderRadius = '4px';
            badgeEl.style.fontSize = '11px';
            badgeEl.style.fontWeight = 'bold';
            badgeEl.textContent = '✓ Matches VAT + Non-VAT';
        }
    }
}

const financialInputIds = ['old_grand_total', 'total_vat', 'total_non_vat'];

financialInputIds.forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;
    
    ['input', 'change', 'keyup', 'paste'].forEach(evt => {
        el.addEventListener(evt, calculateDaily);
    });
    
    el.addEventListener('focus', function() {
        this.select();
    });
    
    el.addEventListener('blur', function() {
        if (this.value.trim() !== '') {
            this.value = formatWithCommas(parseNum(this.value), 2);
        }
        calculateDaily();
    });
});

// Form submit validation to guarantee equality
document.getElementById('journalForm').addEventListener('submit', function(e) {
    const vat = parseNum(document.getElementById('total_vat').value);
    const nonVat = parseNum(document.getElementById('total_non_vat').value);
    const daily = vat + nonVat;
    
    let tenderSum = 0;
    document.querySelectorAll('#tender-body input[name*="[amount]"]').forEach(inp => {
        tenderSum += parseNum(inp.value);
    });
    
    if (Math.abs(daily - tenderSum) > 0.009) {
        e.preventDefault();
        alert('Cannot save: Total VAT + Total Non-VAT (₱' + formatWithCommas(daily) + ') must be equal to Total Tenders (₱' + formatWithCommas(tenderSum) + ').');
        document.getElementById('total_vat').focus();
    }
});

// Compute totals on first load
calculateDaily();
</script>
</body>
</html>
