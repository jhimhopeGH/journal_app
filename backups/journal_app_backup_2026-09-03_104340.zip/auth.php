<?php
// auth.php - Central Authentication & Role-Based Access Control Module
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/db.php';

/**
 * Check if a user is currently logged in.
 */
function isLoggedIn() {
    return !empty($_SESSION['user']['id']);
}

/**
 * Get the currently logged-in user data.
 */
function getCurrentUser() {
    return $_SESSION['user'] ?? null;
}

/**
 * Check if the currently logged-in user has the admin role.
 */
function isAdmin() {
    return isLoggedIn() && (($_SESSION['user']['role'] ?? '') === 'admin');
}

/**
 * Enforce authentication on a page. Redirects unauthenticated visitors to login.php.
 */
function requireLogin() {
    if (!isLoggedIn()) {
        $redirectUrl = $_SERVER['REQUEST_URI'] ?? 'dashboard.php';
        header('Location: login.php?redirect=' . urlencode($redirectUrl));
        exit;
    }
}

/**
 * Enforce admin privileges on a page. Redirects unauthorized users.
 */
function requireAdmin() {
    requireLogin();
    if (!isAdmin()) {
        header('Location: dashboard.php?error=access_denied');
        exit;
    }
}

/**
 * Enforce authentication on JSON AJAX endpoints.
 */
function requireAjaxAuth() {
    if (!isLoggedIn()) {
        http_response_code(401);
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => 'Unauthorized: Please log in.']);
        exit;
    }
}

/**
 * Enforce admin role on JSON AJAX endpoints.
 */
function requireAjaxAdmin() {
    requireAjaxAuth();
    if (!isAdmin()) {
        http_response_code(403);
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => 'Forbidden: Administrator privileges required.']);
        exit;
    }
}

/**
 * Attempt to authenticate a user with username and password.
 */
function loginUser($username, $password) {
    $user = getUserByUsername($username);
    if (!$user) {
        return ['success' => false, 'error' => 'Invalid username or password.'];
    }

    if (empty($user['is_active'])) {
        return ['success' => false, 'error' => 'This account has been deactivated. Please contact an administrator.'];
    }

    if (!password_verify($password, $user['password_hash'])) {
        return ['success' => false, 'error' => 'Invalid username or password.'];
    }

    // Authentication succeeded - Store sanitized user session
    $_SESSION['user'] = [
        'id'        => (int)$user['id'],
        'username'  => $user['username'],
        'full_name' => $user['full_name'] ?: $user['username'],
        'role'      => $user['role'] ?: 'user'
    ];

    return ['success' => true, 'user' => $_SESSION['user']];
}

/**
 * Log out the current user and destroy the session.
 */
function logoutUser() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    $_SESSION = [];
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    session_destroy();
}
