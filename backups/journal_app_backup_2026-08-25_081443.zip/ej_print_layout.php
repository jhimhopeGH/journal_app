<?php
// ej_print_layout.php - Live Interactive Visual Layout & Slider Customizer for Electronic Journal (EJ)
require_once __DIR__ . '/ej_db.php';
$currentPage = 'ej_layout';

$saveMessage = '';
$saveError = '';

// Handle AJAX or Form Save
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $rawInput = file_get_contents('php://input');
    $postData = json_decode($rawInput, true);
    if (!is_array($postData)) {
        $postData = $_POST;
    }

    if (isset($postData['action']) && $postData['action'] === 'save_settings') {
        $newSettings = [
            'paper_size'               => in_array($postData['paper_size'] ?? '', ['a4', 'letter']) ? $postData['paper_size'] : 'a4',
            'sheet_margin'             => (float)($postData['sheet_margin'] ?? 0.30),
            'top_title_margin_top'     => (int)($postData['top_title_margin_top'] ?? 25),
            'top_title_font_size'      => (int)($postData['top_title_font_size'] ?? 16),
            'meta_gap'                 => (int)($postData['meta_gap'] ?? 65),
            'meta_font_size'           => (int)($postData['meta_font_size'] ?? 14),
            'char_width'               => (int)($postData['char_width'] ?? 54),
            'font_size'                => (int)($postData['font_size'] ?? 15),
            'line_height'              => (float)($postData['line_height'] ?? 1.36),
            'receipt_padding_x'        => (int)($postData['receipt_padding_x'] ?? 20),
            'receipt_padding_y'        => (int)($postData['receipt_padding_y'] ?? 6),
            'watermark_text'           => trim((string)($postData['watermark_text'] ?? 'Electronic Journal Copy')),
            'watermark_font_size'      => (int)($postData['watermark_font_size'] ?? 60),
            'watermark_top'            => (int)($postData['watermark_top'] ?? 75),
            'watermark_left'           => (int)($postData['watermark_left'] ?? 50),
            'watermark_opacity'        => (float)($postData['watermark_opacity'] ?? 0.16),
            'watermark_letter_spacing' => (float)($postData['watermark_letter_spacing'] ?? 3)
        ];

        if (saveEjPrintSettings($newSettings)) {
            if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strpos($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json') !== false || !empty($rawInput)) {
                header('Content-Type: application/json');
                echo json_encode(['status' => 'success', 'message' => 'EJ Print Layout Settings saved successfully!']);
                exit;
            }
            $saveMessage = '✓ EJ Print Layout Settings saved successfully!';
        } else {
            if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strpos($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json') !== false) {
                header('Content-Type: application/json');
                echo json_encode(['status' => 'error', 'message' => 'Failed to save settings to ej_print_settings.json']);
                exit;
            }
            $saveError = 'Failed to save settings. Please check file permissions.';
        }
    }
}

$settings = getEjPrintSettings();

// Load a sample EJ entry for realistic live preview
$sampleStmt = $ejPdo->query("SELECT * FROM ej_entries ORDER BY id DESC LIMIT 1");
$sampleEntry = $sampleStmt ? $sampleStmt->fetch(PDO::FETCH_ASSOC) : null;

$sampleDate = $sampleEntry['entry_date'] ?? date('Y-m-d');
$sampleTime = $sampleEntry['entry_time'] ?? date('H:i:s');
$sampleDateTimestamp = strtotime($sampleDate);
$sampleHeaderDate = $sampleDateTimestamp ? date('n j Y', $sampleDateTimestamp) : '1 31 2019';
$sampleTrxDateStr = $sampleDateTimestamp ? date('n/j/y', $sampleDateTimestamp) : '1/31/19';
$sampleTimeFormatted = $sampleTime ? date('H:i', strtotime($sampleTime)) : '10:07';

$sampleStore = $sampleEntry['store_code'] ?? '10005';
$sampleReg   = $sampleEntry['register_number'] ?? '104';
$sampleTill  = $sampleEntry['till_number'] ?? '2454';
$sampleTrx   = $sampleEntry['transaction_number'] ?? '1521';
$sampleTrxFormatted = number_format((float)$sampleTrx, 0);
$sampleRawTrx = preg_replace('/[^\d]/', '', (string)$sampleTrx);
if ($sampleRawTrx === '') $sampleRawTrx = '1521';

$sampleMember = $sampleEntry['member_number'] ?? '6000325461';
$sampleName   = $sampleEntry['customer_name'] ?? 'NOYNAY, MEDELLINO';
$sampleAssoc  = $sampleEntry['sales_associate'] ?? 'GENESIS R.';
$sampleAssocId= $sampleEntry['associate_id'] ?? '88019';
$sampleInvoice= !empty($sampleEntry['invoice_number']) ? str_pad(ltrim($sampleEntry['invoice_number'], '0'), 8, '0', STR_PAD_LEFT) : '00412850';

$sampleItems = json_decode($sampleEntry['items'] ?? '[]', true);
if (empty($sampleItems)) {
    $sampleItems = [
        ['sku' => '102030', 'description' => 'MOGU MOGU LYCHEE 320ML', 'quantity' => 2, 'unit_price' => 45.00, 'amount' => 90.00],
        ['sku' => '204060', 'description' => 'SAN MARINO CORNED TUNA 180G', 'quantity' => 3, 'unit_price' => 38.50, 'amount' => 115.50],
        ['sku' => '305080', 'description' => 'KOPICO BLANCA 30G X 10S', 'quantity' => 1, 'unit_price' => 72.00, 'amount' => 72.00]
    ];
}
$sampleSubtotal = 0;
foreach ($sampleItems as $si) {
    $sampleSubtotal += (float)($si['amount'] ?? 0);
}
$sampleVatRate = (float)($sampleEntry['vat_rate'] ?? 12.0);
$sampleVatableSales = round($sampleSubtotal / 1.12, 2);
$sampleTotalVat = round($sampleSubtotal - $sampleVatableSales, 2);
$sampleNonVat = 0.00;
$sampleTotal = $sampleSubtotal;
$sampleTenderCash = ceil($sampleTotal / 100) * 100;
$sampleChange = $sampleTenderCash - $sampleTotal;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>EJ Print Layout Designer - Electronic Journal</title>
<link rel="stylesheet" href="style.css">
<style>
  :root {
      --primary: #0284c7;
      --primary-dark: #0369a1;
      --panel-bg: #ffffff;
      --border-color: #e2e8f0;
  }
  
  body {
      background: #f8fafc;
      color: #1e293b;
  }
  
  .layout-designer-grid {
      display: grid;
      grid-template-columns: 440px 1fr;
      gap: 24px;
      align-items: start;
  }
  
  @media (max-width: 1100px) {
      .layout-designer-grid {
          grid-template-columns: 1fr;
      }
  }

  /* Controls Panel */
  .controls-card {
      background: #ffffff;
      border: 1px solid #e2e8f0;
      border-radius: 10px;
      box-shadow: 0 4px 16px rgba(0,0,0,0.05);
      padding: 20px;
      position: sticky;
      top: 20px;
      max-height: calc(100vh - 40px);
      overflow-y: auto;
  }

  .control-section {
      margin-bottom: 20px;
      padding-bottom: 16px;
      border-bottom: 1px solid #f1f5f9;
  }
  .control-section:last-child {
      border-bottom: none;
      margin-bottom: 0;
      padding-bottom: 0;
  }
  .section-title {
      font-size: 13px;
      font-weight: 700;
      color: #0f172a;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin-bottom: 12px;
      display: flex;
      align-items: center;
      gap: 8px;
  }
  .section-title span.icon {
      font-size: 16px;
  }

  /* Slider Group */
  .slider-group {
      margin-bottom: 12px;
  }
  .slider-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 12px;
      font-weight: 600;
      color: #475569;
      margin-bottom: 5px;
  }
  .slider-val-badge {
      font-family: 'Courier New', Courier, monospace;
      background: #f1f5f9;
      color: #0284c7;
      font-weight: 700;
      padding: 2px 7px;
      border-radius: 4px;
      font-size: 11.5px;
      border: 1px solid #e2e8f0;
  }
  .slider-input-row {
      display: flex;
      align-items: center;
      gap: 10px;
  }
  input[type="range"] {
      flex: 1;
      height: 6px;
      border-radius: 3px;
      background: #cbd5e1;
      outline: none;
      cursor: pointer;
      accent-color: #0284c7;
  }
  input[type="range"]::-webkit-slider-thumb {
      width: 16px;
      height: 16px;
      border-radius: 50%;
      background: #0284c7;
      cursor: pointer;
      box-shadow: 0 1px 3px rgba(0,0,0,0.3);
  }

  .paper-toggle-group {
      display: flex;
      gap: 10px;
      margin-bottom: 12px;
  }
  .paper-toggle-btn {
      flex: 1;
      padding: 8px 12px;
      border: 2px solid #cbd5e1;
      background: #f8fafc;
      border-radius: 6px;
      font-weight: 700;
      font-size: 12px;
      color: #475569;
      cursor: pointer;
      text-align: center;
      transition: all 0.15s ease;
  }
  .paper-toggle-btn.active {
      border-color: #0284c7;
      background: #e0f2fe;
      color: #0369a1;
  }

  /* Live Preview Canvas */
  .preview-wrapper {
      background: #334155;
      padding: 24px 16px 80px 16px;
      border-radius: 10px;
      box-shadow: inset 0 2px 10px rgba(0,0,0,0.25);
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 16px;
      min-height: 800px;
  }

  .preview-toolbar {
      width: 100%;
      max-width: 820px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: #1e293b;
      color: #fff;
      padding: 8px 16px;
      border-radius: 6px;
      font-size: 12px;
      font-weight: 600;
  }
  .preview-toolbar button {
      background: #475569;
      color: #fff;
      border: none;
      padding: 4px 10px;
      border-radius: 4px;
      cursor: pointer;
      font-size: 11px;
      transition: background 0.15s ease;
  }
  .preview-toolbar button:hover {
      background: #64748b;
  }

  /* WYSIWYG Sheet Preview */
  .sheet-preview {
      background: #ffffff;
      color: #000000;
      box-shadow: 0 10px 35px rgba(0,0,0,0.35);
      border-radius: 2px;
      position: relative;
      box-sizing: border-box;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      transition: width 0.2s ease, min-height 0.2s ease, padding 0.15s ease;
      overflow: hidden;
  }
  
  .sheet-preview.size-a4 {
      width: 210mm;
      min-height: 297mm;
  }
  .sheet-preview.size-letter {
      width: 8.5in;
      min-height: 11in;
  }

  /* Printable Margin Guide */
  .sheet-margin-guide {
      position: absolute;
      border: 1px dashed #94a3b8;
      pointer-events: none;
      z-index: 0;
      transition: all 0.15s ease;
  }
  .sheet-margin-guide::before {
      content: attr(data-label);
      position: absolute;
      top: -16px;
      left: 0;
      font-family: system-ui, sans-serif;
      font-size: 10px;
      color: #94a3b8;
      font-weight: bold;
  }

  /* Receipt Container */
  .preview-receipt-container {
      width: 100%;
      max-width: 100%;
      margin: 0;
      position: relative;
      z-index: 1;
  }

  .preview-header-title {
      text-align: center;
      font-weight: 800;
      color: #000000;
      letter-spacing: 0.5px;
      transition: margin 0.15s ease, font-size 0.15s ease;
  }

  .preview-footer-title {
      text-align: center;
      font-weight: 800;
      margin-top: auto;
      margin-bottom: 0;
      padding-top: 16px;
      color: #000000;
      letter-spacing: 0.5px;
      position: relative;
      z-index: 1;
      width: 100%;
      transition: font-size 0.15s ease;
  }

  .preview-meta-bar {
      display: flex;
      justify-content: center;
      align-items: center;
      color: #000000;
      padding-bottom: 6px;
      border-bottom: 1.5px solid #000000;
      width: 100%;
      transition: gap 0.15s ease, font-size 0.15s ease;
  }
  .preview-meta-bar .meta-item span.label {
      font-weight: 800;
  }
  .preview-meta-bar .meta-item span.val {
      font-weight: 700;
  }

  .preview-body-wrapper {
      position: relative;
      margin-top: 10px;
      padding-bottom: 8px;
      border-bottom: 1.5px solid #000000;
      width: 100%;
      min-height: 420px;
  }

  .preview-watermark {
      position: absolute;
      transform: translate(-50%, -50%) rotate(-90deg);
      transform-origin: center center;
      font-family: Arial, Helvetica, sans-serif;
      font-weight: 300;
      color: rgba(6, 182, 212, 0.16);
      white-space: nowrap;
      pointer-events: none;
      z-index: 1;
      user-select: none;
      transition: all 0.15s ease;
  }

  pre.preview-content {
      position: relative;
      z-index: 2;
      font-family: 'Courier New', Courier, 'Lucida Console', monospace;
      font-weight: 400;
      color: #000000;
      margin: 0;
      white-space: pre;
      transition: all 0.15s ease;
  }

  .save-toast {
      position: fixed;
      bottom: 24px;
      right: 24px;
      background: #16a34a;
      color: #ffffff;
      padding: 12px 24px;
      border-radius: 8px;
      font-weight: 700;
      font-size: 14px;
      box-shadow: 0 10px 25px rgba(0,0,0,0.25);
      z-index: 9999;
      opacity: 0;
      transform: translateY(20px);
      transition: all 0.3s ease;
      pointer-events: none;
  }
  .save-toast.show {
      opacity: 1;
      transform: translateY(0);
  }
</style>
</head>
<body>
<div class="app-shell">
    <?php require __DIR__ . '/partials/nav.php'; ?>

    <main class="main-content">
        <div class="page-header" style="display: flex; justify-content: space-between; align-items: flex-start;">
            <div>
                <h1>EJ Print Layout Designer</h1>
                <p>Interactive slider customizer and live WYSIWYG preview for Electronic Journal printouts.</p>
            </div>
            <div style="display: flex; gap: 10px;">
                <a href="ej_print.php?id=<?php echo (int)($sampleEntry['id'] ?? 1); ?>" target="_blank" class="btn btn-secondary">🖨️ View ej_print.php</a>
                <button type="button" id="btn_save_top" class="btn" style="padding: 9px 22px; font-weight: 700;">💾 Save Layout</button>
            </div>
        </div>

        <?php if ($saveMessage): ?>
            <div class="success"><?php echo htmlspecialchars($saveMessage); ?></div>
        <?php endif; ?>
        <?php if ($saveError): ?>
            <div class="danger"><?php echo htmlspecialchars($saveError); ?></div>
        <?php endif; ?>

        <div class="layout-designer-grid">
            
            <!-- Left: Sliders Controls Panel -->
            <div class="controls-card">
                <form id="ejSettingsForm" method="POST" action="ej_print_layout.php">
                    <input type="hidden" name="action" value="save_settings">

                    <!-- Section 1: Paper & Margins -->
                    <div class="control-section">
                        <div class="section-title"><span class="icon">📄</span> Paper & Margins</div>
                        
                        <div class="paper-toggle-group">
                            <input type="hidden" name="paper_size" id="paper_size" value="<?php echo htmlspecialchars($settings['paper_size'] ?? 'a4'); ?>">
                            <button type="button" class="paper-toggle-btn <?php echo ($settings['paper_size'] ?? 'a4') === 'a4' ? 'active' : ''; ?>" data-paper="a4">A4 (210 × 297mm)</button>
                            <button type="button" class="paper-toggle-btn <?php echo ($settings['paper_size'] ?? 'a4') === 'letter' ? 'active' : ''; ?>" data-paper="letter">US Letter (8.5" × 11")</button>
                        </div>

                        <div class="slider-group">
                            <div class="slider-header">
                                <span>Sheet Margin (in):</span>
                                <span class="slider-val-badge" id="val_sheet_margin"><?php echo number_format((float)($settings['sheet_margin'] ?? 0.30), 2); ?> in</span>
                            </div>
                            <div class="slider-input-row">
                                <input type="range" name="sheet_margin" id="sheet_margin" min="0.10" max="0.75" step="0.01" value="<?php echo (float)($settings['sheet_margin'] ?? 0.30); ?>">
                            </div>
                        </div>
                    </div>

                    <!-- Section 2: Header & Footer Titles -->
                    <div class="control-section">
                        <div class="section-title"><span class="icon">🏷️</span> Header & Footer Title</div>
                        
                        <div class="slider-group">
                            <div class="slider-header">
                                <span>Top Title Margin Top (Offset):</span>
                                <span class="slider-val-badge" id="val_top_title_margin_top"><?php echo (int)($settings['top_title_margin_top'] ?? 25); ?> px</span>
                            </div>
                            <div class="slider-input-row">
                                <input type="range" name="top_title_margin_top" id="top_title_margin_top" min="0" max="70" step="1" value="<?php echo (int)($settings['top_title_margin_top'] ?? 25); ?>">
                            </div>
                        </div>

                        <div class="slider-group">
                            <div class="slider-header">
                                <span>Title Font Size:</span>
                                <span class="slider-val-badge" id="val_top_title_font_size"><?php echo (int)($settings['top_title_font_size'] ?? 16); ?> px</span>
                            </div>
                            <div class="slider-input-row">
                                <input type="range" name="top_title_font_size" id="top_title_font_size" min="12" max="24" step="1" value="<?php echo (int)($settings['top_title_font_size'] ?? 16); ?>">
                            </div>
                        </div>
                    </div>

                    <!-- Section 3: Metadata Bar -->
                    <div class="control-section">
                        <div class="section-title"><span class="icon">📊</span> Metadata Bar (Date/Store/Reg/Trx)</div>
                        
                        <div class="slider-group">
                            <div class="slider-header">
                                <span>Items Spacing (Gap):</span>
                                <span class="slider-val-badge" id="val_meta_gap"><?php echo (int)($settings['meta_gap'] ?? 65); ?> px</span>
                            </div>
                            <div class="slider-input-row">
                                <input type="range" name="meta_gap" id="meta_gap" min="15" max="110" step="1" value="<?php echo (int)($settings['meta_gap'] ?? 65); ?>">
                            </div>
                        </div>

                        <div class="slider-group">
                            <div class="slider-header">
                                <span>Meta Font Size:</span>
                                <span class="slider-val-badge" id="val_meta_font_size"><?php echo (int)($settings['meta_font_size'] ?? 14); ?> px</span>
                            </div>
                            <div class="slider-input-row">
                                <input type="range" name="meta_font_size" id="meta_font_size" min="10" max="20" step="1" value="<?php echo (int)($settings['meta_font_size'] ?? 14); ?>">
                            </div>
                        </div>
                    </div>

                    <!-- Section 4: Receipt Monospace Body -->
                    <div class="control-section">
                        <div class="section-title"><span class="icon">🧾</span> Receipt Body & Typography</div>
                        
                        <div class="slider-group">
                            <div class="slider-header">
                                <span>Monospace Font Size:</span>
                                <span class="slider-val-badge" id="val_font_size"><?php echo (int)($settings['font_size'] ?? 15); ?> px</span>
                            </div>
                            <div class="slider-input-row">
                                <input type="range" name="font_size" id="font_size" min="11" max="20" step="0.5" value="<?php echo (float)($settings['font_size'] ?? 15); ?>">
                            </div>
                        </div>

                        <div class="slider-group">
                            <div class="slider-header">
                                <span>Character Column Width ($W):</span>
                                <span class="slider-val-badge" id="val_char_width"><?php echo (int)($settings['char_width'] ?? 54); ?> chars</span>
                            </div>
                            <div class="slider-input-row">
                                <input type="range" name="char_width" id="char_width" min="40" max="64" step="1" value="<?php echo (int)($settings['char_width'] ?? 54); ?>">
                            </div>
                        </div>

                        <div class="slider-group">
                            <div class="slider-header">
                                <span>Line Height:</span>
                                <span class="slider-val-badge" id="val_line_height"><?php echo number_format((float)($settings['line_height'] ?? 1.36), 2); ?></span>
                            </div>
                            <div class="slider-input-row">
                                <input type="range" name="line_height" id="line_height" min="1.10" max="1.80" step="0.02" value="<?php echo (float)($settings['line_height'] ?? 1.36); ?>">
                            </div>
                        </div>

                        <div class="slider-group">
                            <div class="slider-header">
                                <span>Horizontal Indent (Padding X):</span>
                                <span class="slider-val-badge" id="val_receipt_padding_x"><?php echo (int)($settings['receipt_padding_x'] ?? 20); ?> px</span>
                            </div>
                            <div class="slider-input-row">
                                <input type="range" name="receipt_padding_x" id="receipt_padding_x" min="0" max="50" step="1" value="<?php echo (int)($settings['receipt_padding_x'] ?? 20); ?>">
                            </div>
                        </div>

                        <div class="slider-group">
                            <div class="slider-header">
                                <span>Vertical Padding (Padding Y):</span>
                                <span class="slider-val-badge" id="val_receipt_padding_y"><?php echo (int)($settings['receipt_padding_y'] ?? 6); ?> px</span>
                            </div>
                            <div class="slider-input-row">
                                <input type="range" name="receipt_padding_y" id="receipt_padding_y" min="0" max="25" step="1" value="<?php echo (int)($settings['receipt_padding_y'] ?? 6); ?>">
                            </div>
                        </div>
                    </div>

                    <!-- Section 5: Watermark -->
                    <div class="control-section">
                        <div class="section-title"><span class="icon">💧</span> Watermark Settings</div>
                        
                        <div style="margin-bottom: 12px;">
                            <label style="font-size: 12px; font-weight: 600; color: #475569; display: block; margin-bottom: 4px;">Watermark Text:</label>
                            <input type="text" name="watermark_text" id="watermark_text" value="<?php echo htmlspecialchars($settings['watermark_text'] ?? 'Electronic Journal Copy'); ?>" style="width: 100%; box-sizing: border-box; padding: 6px 10px; font-size: 13px; border: 1px solid #cbd5e1; border-radius: 4px;">
                        </div>

                        <div class="slider-group">
                            <div class="slider-header">
                                <span>Watermark Font Size:</span>
                                <span class="slider-val-badge" id="val_watermark_font_size"><?php echo (int)($settings['watermark_font_size'] ?? 60); ?> px</span>
                            </div>
                            <div class="slider-input-row">
                                <input type="range" name="watermark_font_size" id="watermark_font_size" min="30" max="90" step="1" value="<?php echo (int)($settings['watermark_font_size'] ?? 60); ?>">
                            </div>
                        </div>

                        <div class="slider-group">
                            <div class="slider-header">
                                <span>Vertical Position (Top %):</span>
                                <span class="slider-val-badge" id="val_watermark_top"><?php echo (int)($settings['watermark_top'] ?? 75); ?>%</span>
                            </div>
                            <div class="slider-input-row">
                                <input type="range" name="watermark_top" id="watermark_top" min="20" max="95" step="1" value="<?php echo (int)($settings['watermark_top'] ?? 75); ?>">
                            </div>
                        </div>

                        <div class="slider-group">
                            <div class="slider-header">
                                <span>Horizontal Position (Left %):</span>
                                <span class="slider-val-badge" id="val_watermark_left"><?php echo (int)($settings['watermark_left'] ?? 50); ?>%</span>
                            </div>
                            <div class="slider-input-row">
                                <input type="range" name="watermark_left" id="watermark_left" min="15" max="85" step="1" value="<?php echo (int)($settings['watermark_left'] ?? 50); ?>">
                            </div>
                        </div>

                        <div class="slider-group">
                            <div class="slider-header">
                                <span>Opacity / Transparency:</span>
                                <span class="slider-val-badge" id="val_watermark_opacity"><?php echo round(((float)($settings['watermark_opacity'] ?? 0.16)) * 100); ?>%</span>
                            </div>
                            <div class="slider-input-row">
                                <input type="range" name="watermark_opacity" id="watermark_opacity" min="0.05" max="0.50" step="0.01" value="<?php echo (float)($settings['watermark_opacity'] ?? 0.16); ?>">
                            </div>
                        </div>

                        <div class="slider-group">
                            <div class="slider-header">
                                <span>Letter Spacing:</span>
                                <span class="slider-val-badge" id="val_watermark_letter_spacing"><?php echo (float)($settings['watermark_letter_spacing'] ?? 3); ?> px</span>
                            </div>
                            <div class="slider-input-row">
                                <input type="range" name="watermark_letter_spacing" id="watermark_letter_spacing" min="0" max="10" step="0.5" value="<?php echo (float)($settings['watermark_letter_spacing'] ?? 3); ?>">
                            </div>
                        </div>
                    </div>

                    <!-- Action Buttons -->
                    <div style="margin-top: 24px; display: flex; flex-direction: column; gap: 8px;">
                        <button type="submit" class="btn" id="btn_save_bottom" style="width: 100%; padding: 12px; font-weight: 700; font-size: 14px;">💾 Save All Changes</button>
                        <button type="button" id="btn_reset_defaults" class="btn btn-secondary" style="width: 100%; padding: 8px; font-size: 12px;">🔄 Reset to Defaults</button>
                    </div>
                </form>
            </div>

            <!-- Right: Live WYSIWYG Sheet Preview Canvas -->
            <div class="preview-wrapper">
                <div class="preview-toolbar">
                    <span id="preview_badge">📄 A4 Paper: 210mm × 297mm | Margins: 0.30" All Sides</span>
                    <button type="button" id="toggle_guide_btn">📐 Toggle Margins</button>
                </div>

                <!-- Sheet -->
                <div id="liveSheet" class="sheet-preview size-<?php echo htmlspecialchars($settings['paper_size'] ?? 'a4'); ?>">
                    <div id="liveMarginGuide" class="sheet-margin-guide" data-label="0.30in Margin"></div>

                    <div class="preview-receipt-container">
                        <!-- Top Title -->
                        <div id="liveHeaderTitle" class="preview-header-title">*** Electronic Journal Copy ***</div>

                        <!-- Meta Bar -->
                        <div id="liveMetaBar" class="preview-meta-bar">
                            <div class="meta-item"><span class="label">Date:</span> <span class="val" id="meta_date"><?php echo htmlspecialchars($sampleHeaderDate); ?></span></div>
                            <div class="meta-item"><span class="label">Store:</span> <span class="val" id="meta_store"><?php echo htmlspecialchars($sampleStore); ?></span></div>
                            <div class="meta-item"><span class="label">Register:</span> <span class="val" id="meta_reg"><?php echo htmlspecialchars($sampleReg); ?></span></div>
                            <div class="meta-item"><span class="label">Transaction:</span> <span class="val" id="meta_trx"><?php echo htmlspecialchars($sampleTrxFormatted); ?></span></div>
                        </div>

                        <!-- Receipt Body with Watermark -->
                        <div class="preview-body-wrapper">
                            <div id="liveWatermark" class="preview-watermark"><?php echo htmlspecialchars($settings['watermark_text'] ?? 'Electronic Journal Copy'); ?></div>
                            <pre id="liveReceiptText" class="preview-content"></pre>
                        </div>
                    </div>

                    <!-- Bottom Pinned Title -->
                    <div id="liveFooterTitle" class="preview-footer-title">*** Electronic Journal Copy ***</div>
                </div>
            </div>

        </div>
    </main>
</div>

<div id="saveToast" class="save-toast">✓ EJ Print Layout Settings saved successfully!</div>

<script>
// Sample transaction data for live preview rendering
const sampleData = {
    member: <?php echo json_encode($sampleMember); ?>,
    name: <?php echo json_encode($sampleName); ?>,
    items: <?php echo json_encode($sampleItems); ?>,
    subtotal: <?php echo (float)$sampleSubtotal; ?>,
    vatableSales: <?php echo (float)$sampleVatableSales; ?>,
    totalVat: <?php echo (float)$sampleTotalVat; ?>,
    totalNonVat: <?php echo (float)$sampleNonVat; ?>,
    totalAmount: <?php echo (float)$sampleTotal; ?>,
    tenderCash: <?php echo (float)$sampleTenderCash; ?>,
    change: <?php echo (float)$sampleChange; ?>,
    vatRate: <?php echo (float)$sampleVatRate; ?>,
    salesAssoc: <?php echo json_encode($sampleAssoc); ?>,
    assocId: <?php echo json_encode($sampleAssocId); ?>,
    trxSummary: <?php echo json_encode("Trx {$sampleRawTrx} S{$sampleStore} Reg{$sampleReg}/{$sampleTill} {$sampleTrxDateStr}{$sampleTimeFormatted}"); ?>,
    invoice: <?php echo json_encode($sampleInvoice); ?>
};

// Recommended default settings
const defaultSettings = {
    paper_size: 'a4',
    sheet_margin: 0.30,
    top_title_margin_top: 25,
    top_title_font_size: 16,
    meta_gap: 65,
    meta_font_size: 14,
    char_width: 54,
    font_size: 15,
    line_height: 1.36,
    receipt_padding_x: 20,
    receipt_padding_y: 6,
    watermark_text: 'Electronic Journal Copy',
    watermark_font_size: 60,
    watermark_top: 75,
    watermark_left: 50,
    watermark_opacity: 0.16,
    watermark_letter_spacing: 3
};

// DOM elements
const el = {
    form: document.getElementById('ejSettingsForm'),
    paperSize: document.getElementById('paper_size'),
    sheetMargin: document.getElementById('sheet_margin'),
    topTitleMarginTop: document.getElementById('top_title_margin_top'),
    topTitleFontSize: document.getElementById('top_title_font_size'),
    metaGap: document.getElementById('meta_gap'),
    metaFontSize: document.getElementById('meta_font_size'),
    charWidth: document.getElementById('char_width'),
    fontSize: document.getElementById('font_size'),
    lineHeight: document.getElementById('line_height'),
    receiptPaddingX: document.getElementById('receipt_padding_x'),
    receiptPaddingY: document.getElementById('receipt_padding_y'),
    watermarkText: document.getElementById('watermark_text'),
    watermarkFontSize: document.getElementById('watermark_font_size'),
    watermarkTop: document.getElementById('watermark_top'),
    watermarkLeft: document.getElementById('watermark_left'),
    watermarkOpacity: document.getElementById('watermark_opacity'),
    watermarkLetterSpacing: document.getElementById('watermark_letter_spacing'),

    // Live preview elements
    liveSheet: document.getElementById('liveSheet'),
    liveMarginGuide: document.getElementById('liveMarginGuide'),
    liveHeaderTitle: document.getElementById('liveHeaderTitle'),
    liveFooterTitle: document.getElementById('liveFooterTitle'),
    liveMetaBar: document.getElementById('liveMetaBar'),
    liveWatermark: document.getElementById('liveWatermark'),
    liveReceiptText: document.getElementById('liveReceiptText'),
    previewBadge: document.getElementById('preview_badge'),
    saveToast: document.getElementById('saveToast')
};

// Generate Monospace Receipt Text dynamically based on character width
function generateMonospaceText(W) {
    const divDouble = '='.repeat(W);
    const divDash   = '-'.repeat(W);
    let lines = [];

    lines.push(divDouble);
    lines.push('Member #:      ' + (sampleData.member ? sampleData.member : '              '));
    lines.push('Name     : ' + (sampleData.name ? sampleData.name : ''));
    lines.push(divDouble);

    // Line items (2-line format with 9-digit padded SKU)
    sampleData.items.forEach(itm => {
        let rawSku = String(itm.sku || '').trim().padStart(9, '0');
        let skuCol = rawSku.padEnd(16, ' ');
        let desc = itm.description || '';
        lines.push('  ' + skuCol + '   ' + desc);

        let qty = Number(itm.quantity || 1);
        let amt = Number(itm.amount || 0);
        let uPrice = Number(itm.unit_price || (qty > 0 ? amt / qty : amt));
        let uPriceStr = 'P' + uPrice.toFixed(2);
        let amtStr    = 'P' + amt.toFixed(2) + 'V';

        let line2 = uPriceStr.padStart(16, ' ') + 
                    qty.toFixed(0).padStart(6, ' ') + 
                    amtStr.padStart(20, ' ');
        lines.push(line2);
    });

    lines.push('Sub Total'.padStart(28, ' ') + ('P' + sampleData.subtotal.toFixed(2)).padStart(20, ' '));
    lines.push('Tax'.padStart(22, ' ') + 'P0.00'.padStart(26, ' '));
    lines.push('');
    lines.push('Total'.padStart(24, ' ') + ('P' + sampleData.totalAmount.toFixed(2)).padStart(24, ' '));
    lines.push('Cash'.padStart(23, ' ') + ('P' + sampleData.tenderCash.toFixed(2)).padStart(25, ' '));
    
    let changeStr = 'P-' + Math.abs(sampleData.change).toFixed(2);
    lines.push('CHANGE'.padStart(25, ' ') + changeStr.padStart(18, ' '));

    let vatRateStr = sampleData.vatRate.toFixed(4);
    let vatAmtStr = 'P' + sampleData.totalVat.toFixed(2);
    lines.push('     BIR    VAT   @ ' + vatRateStr + vatAmtStr.padStart(20, ' '));

    lines.push('Sales Associate:' + sampleData.salesAssoc);
    lines.push('Associate Id:    ' + sampleData.assocId);
    lines.push(sampleData.trxSummary);
    lines.push('Invoice#:' + sampleData.invoice);

    lines.push(divDash);
    lines.push('VATable Sales:' + ('P' + sampleData.vatableSales.toFixed(2)).padStart(22, ' '));
    lines.push('VAT:          ' + ('P' + sampleData.totalVat.toFixed(2)).padStart(22, ' '));
    lines.push('Non-VATable Sales:' + ('P' + sampleData.totalNonVat.toFixed(2)).padStart(18, ' '));

    return lines.join('\n');
}

// Live update function triggered on every slider movement
function updateLivePreview() {
    const paper = el.paperSize.value;
    const margin = parseFloat(el.sheetMargin.value) || 0.30;
    const topMarginTop = parseInt(el.topTitleMarginTop.value) || 25;
    const topFontSize = parseInt(el.topTitleFontSize.value) || 16;
    const metaGap = parseInt(el.metaGap.value) || 65;
    const metaFontSize = parseInt(el.metaFontSize.value) || 14;
    const charW = parseInt(el.charWidth.value) || 54;
    const fontSize = parseFloat(el.fontSize.value) || 15;
    const lineHeight = parseFloat(el.lineHeight.value) || 1.36;
    const padX = parseInt(el.receiptPaddingX.value) || 20;
    const padY = parseInt(el.receiptPaddingY.value) || 6;
    const wmText = el.watermarkText.value || 'Electronic Journal Copy';
    const wmSize = parseInt(el.watermarkFontSize.value) || 60;
    const wmTop = parseInt(el.watermarkTop.value) || 75;
    const wmLeft = parseInt(el.watermarkLeft.value) || 50;
    const wmOpacity = parseFloat(el.watermarkOpacity.value) || 0.16;
    const wmSpacing = parseFloat(el.watermarkLetterSpacing.value) || 3;

    // Update badges
    document.getElementById('val_sheet_margin').textContent = margin.toFixed(2) + ' in';
    document.getElementById('val_top_title_margin_top').textContent = topMarginTop + ' px';
    document.getElementById('val_top_title_font_size').textContent = topFontSize + ' px';
    document.getElementById('val_meta_gap').textContent = metaGap + ' px';
    document.getElementById('val_meta_font_size').textContent = metaFontSize + ' px';
    document.getElementById('val_char_width').textContent = charW + ' chars';
    document.getElementById('val_font_size').textContent = fontSize + ' px';
    document.getElementById('val_line_height').textContent = lineHeight.toFixed(2);
    document.getElementById('val_receipt_padding_x').textContent = padX + ' px';
    document.getElementById('val_receipt_padding_y').textContent = padY + ' px';
    document.getElementById('val_watermark_font_size').textContent = wmSize + ' px';
    document.getElementById('val_watermark_top').textContent = wmTop + '%';
    document.getElementById('val_watermark_left').textContent = wmLeft + '%';
    document.getElementById('val_watermark_opacity').textContent = Math.round(wmOpacity * 100) + '%';
    document.getElementById('val_watermark_letter_spacing').textContent = wmSpacing + ' px';

    // Update Paper size class
    el.liveSheet.className = 'sheet-preview size-' + paper;
    const paperLabel = paper === 'a4' ? 'A4 Paper: 210mm × 297mm' : 'US Letter: 8.5" × 11.0"';
    el.previewBadge.textContent = '📄 ' + paperLabel + ' | Margins: ' + margin.toFixed(2) + '" All Sides';

    // Update sheet padding & margin guide
    el.liveSheet.style.padding = margin + 'in';
    el.liveMarginGuide.style.top = margin + 'in';
    el.liveMarginGuide.style.left = margin + 'in';
    el.liveMarginGuide.style.right = margin + 'in';
    el.liveMarginGuide.style.bottom = margin + 'in';
    el.liveMarginGuide.setAttribute('data-label', margin.toFixed(2) + 'in Margin');

    // Update Top & Bottom Titles
    el.liveHeaderTitle.style.marginTop = topMarginTop + 'px';
    el.liveHeaderTitle.style.fontSize = topFontSize + 'px';
    el.liveFooterTitle.style.fontSize = topFontSize + 'px';

    // Update Meta Bar
    el.liveMetaBar.style.gap = metaGap + 'px';
    el.liveMetaBar.style.fontSize = metaFontSize + 'px';

    // Update Watermark
    el.liveWatermark.textContent = wmText;
    el.liveWatermark.style.fontSize = wmSize + 'px';
    el.liveWatermark.style.top = wmTop + '%';
    el.liveWatermark.style.left = wmLeft + '%';
    el.liveWatermark.style.color = `rgba(6, 182, 212, ${wmOpacity})`;
    el.liveWatermark.style.letterSpacing = wmSpacing + 'px';

    // Update Monospace receipt
    el.liveReceiptText.style.fontSize = fontSize + 'px';
    el.liveReceiptText.style.lineHeight = lineHeight;
    el.liveReceiptText.style.padding = `${padY}px ${padX}px`;
    el.liveReceiptText.textContent = generateMonospaceText(charW);
}

// Paper toggle button listeners
document.querySelectorAll('.paper-toggle-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.paper-toggle-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        el.paperSize.value = btn.getAttribute('data-paper');
        updateLivePreview();
    });
});

// Attach input listener to all range and text inputs
const allInputs = [
    el.sheetMargin, el.topTitleMarginTop, el.topTitleFontSize,
    el.metaGap, el.metaFontSize, el.charWidth, el.fontSize,
    el.lineHeight, el.receiptPaddingX, el.receiptPaddingY,
    el.watermarkText, el.watermarkFontSize, el.watermarkTop,
    el.watermarkLeft, el.watermarkOpacity, el.watermarkLetterSpacing
];
allInputs.forEach(input => {
    if (input) {
        input.addEventListener('input', updateLivePreview);
    }
});

// Toggle Margin Guide button
document.getElementById('toggle_guide_btn').addEventListener('click', () => {
    const isHidden = el.liveMarginGuide.style.display === 'none';
    el.liveMarginGuide.style.display = isHidden ? 'block' : 'none';
});

// Reset to Defaults
document.getElementById('btn_reset_defaults').addEventListener('click', () => {
    if (!confirm('Reset all layout settings to recommended defaults?')) return;
    
    el.paperSize.value = defaultSettings.paper_size;
    document.querySelectorAll('.paper-toggle-btn').forEach(b => {
        b.classList.toggle('active', b.getAttribute('data-paper') === defaultSettings.paper_size);
    });

    el.sheetMargin.value = defaultSettings.sheet_margin;
    el.topTitleMarginTop.value = defaultSettings.top_title_margin_top;
    el.topTitleFontSize.value = defaultSettings.top_title_font_size;
    el.metaGap.value = defaultSettings.meta_gap;
    el.metaFontSize.value = defaultSettings.meta_font_size;
    el.charWidth.value = defaultSettings.char_width;
    el.fontSize.value = defaultSettings.font_size;
    el.lineHeight.value = defaultSettings.line_height;
    el.receiptPaddingX.value = defaultSettings.receipt_padding_x;
    el.receiptPaddingY.value = defaultSettings.receipt_padding_y;
    el.watermarkText.value = defaultSettings.watermark_text;
    el.watermarkFontSize.value = defaultSettings.watermark_font_size;
    el.watermarkTop.value = defaultSettings.watermark_top;
    el.watermarkLeft.value = defaultSettings.watermark_left;
    el.watermarkOpacity.value = defaultSettings.watermark_opacity;
    el.watermarkLetterSpacing.value = defaultSettings.watermark_letter_spacing;

    updateLivePreview();
});

// AJAX Save Settings Handler
function saveSettingsViaAjax(e) {
    if (e) e.preventDefault();
    const payload = {
        action: 'save_settings',
        paper_size: el.paperSize.value,
        sheet_margin: parseFloat(el.sheetMargin.value),
        top_title_margin_top: parseInt(el.topTitleMarginTop.value),
        top_title_font_size: parseInt(el.topTitleFontSize.value),
        meta_gap: parseInt(el.metaGap.value),
        meta_font_size: parseInt(el.metaFontSize.value),
        char_width: parseInt(el.charWidth.value),
        font_size: parseFloat(el.fontSize.value),
        line_height: parseFloat(el.lineHeight.value),
        receipt_padding_x: parseInt(el.receiptPaddingX.value),
        receipt_padding_y: parseInt(el.receiptPaddingY.value),
        watermark_text: el.watermarkText.value,
        watermark_font_size: parseInt(el.watermarkFontSize.value),
        watermark_top: parseInt(el.watermarkTop.value),
        watermark_left: parseInt(el.watermarkLeft.value),
        watermark_opacity: parseFloat(el.watermarkOpacity.value),
        watermark_letter_spacing: parseFloat(el.watermarkLetterSpacing.value)
    };

    fetch('ej_print_layout.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: JSON.stringify(payload)
    })
    .then(res => res.json())
    .then(data => {
        const toast = el.saveToast;
        toast.textContent = data.message || '✓ Layout Settings Saved!';
        toast.style.background = data.status === 'success' ? '#16a34a' : '#dc2626';
        toast.classList.add('show');
        setTimeout(() => toast.classList.remove('show'), 2800);
    })
    .catch(err => {
        el.form.submit(); // fallback to standard submit
    });
}

el.form.addEventListener('submit', saveSettingsViaAjax);
document.getElementById('btn_save_top').addEventListener('click', () => saveSettingsViaAjax());

// Initialize live preview on page load
updateLivePreview();
</script>
</body>
</html>
