<?php
// ej_print_batch.php - Batch Letter paper print view for Electronic Journal Copy
require_once __DIR__ . '/ej_db.php';

$idsParam = isset($_GET['ids']) ? trim($_GET['ids']) : (isset($_POST['ids']) ? (is_array($_POST['ids']) ? implode(',', $_POST['ids']) : trim($_POST['ids'])) : '');
$idList = array_filter(array_map('intval', explode(',', $idsParam)));

if (empty($idList)) {
    echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><link rel="stylesheet" href="style.css"></head><body>
          <div class="container"><h1>No entries selected for batch printing</h1>
          <a class="btn" href="ej_printing.php">Back to EJ Records</a></div></body></html>';
    exit;
}

$inClause = implode(',', $idList);
$stmt = $ejPdo->query("SELECT * FROM ej_entries WHERE id IN ($inClause) ORDER BY entry_date ASC, id ASC");
$entries = $stmt->fetchAll(PDO::FETCH_ASSOC);

$tenderNameMap = getTenderNameMap();

$settings = getEjPrintSettings();
$paperSize = $settings['paper_size'] ?? 'a4';
$sheetMargin = (float)($settings['sheet_margin'] ?? 0.30);
$topTitleMarginTop = (int)($settings['top_title_margin_top'] ?? 25);
$topTitleFontSize = (int)($settings['top_title_font_size'] ?? 16);
$metaGap = (int)($settings['meta_gap'] ?? 65);
$metaFontSize = (int)($settings['meta_font_size'] ?? 14);
$W = (int)($settings['char_width'] ?? 54);
$fontSize = (float)($settings['font_size'] ?? 15);
$lineHeight = (float)($settings['line_height'] ?? 1.36);
$receiptPaddingX = (int)($settings['receipt_padding_x'] ?? 20);
$receiptPaddingY = (int)($settings['receipt_padding_y'] ?? 6);
$wmText = $settings['watermark_text'] ?? 'Electronic Journal Copy';
$wmFontSize = (int)($settings['watermark_font_size'] ?? 60);
$wmTop = (int)($settings['watermark_top'] ?? 75);
$wmLeft = (int)($settings['watermark_left'] ?? 50);
$wmOpacity = (float)($settings['watermark_opacity'] ?? 0.16);
$wmLetterSpacing = (float)($settings['watermark_letter_spacing'] ?? 3);

function formatSingleEjReceipt($entry, $tenderNameMap, $W) {
    // Format Date for Header: e.g. "1 31 2019"
    $rawDate = $entry['entry_date'] ?? '';
    $dateTimestamp = strtotime($rawDate);
    if ($dateTimestamp) {
        $headerDate = date('n j Y', $dateTimestamp);
        $trxDateStr = date('n/j/y', $dateTimestamp);
    } else {
        $headerDate = $rawDate;
        $trxDateStr = $rawDate;
    }

    $rawTime = $entry['entry_time'] ?? '';
    $timeFormatted = $rawTime ? date('H:i', strtotime($rawTime)) : '';

    $decodedItems = json_decode($entry['items'] ?? '[]', true);
    if (!is_array($decodedItems)) $decodedItems = [];

    $decodedTenders = json_decode($entry['tenders'] ?? '[]', true);
    if (!is_array($decodedTenders)) $decodedTenders = [];

    $subtotal     = (float)($entry['subtotal'] ?? 0);
    $vatableSales = (float)($entry['vatable_sales'] ?? 0);
    $totalVat     = (float)($entry['total_vat'] ?? 0);
    $totalNonVat  = (float)($entry['total_non_vat'] ?? 0);
    $totalAmount  = (float)($entry['total_amount'] ?? 0);
    $vatRate      = (float)($entry['vat_rate'] ?? 12.0);

    $totalTendered = 0;
    foreach ($decodedTenders as $t) {
        $totalTendered += (float)($t['amount'] ?? 0);
    }
    if (empty($decodedTenders)) {
        $totalTendered = $totalAmount;
    }
    $change = $totalTendered - $totalAmount;

    $invoiceFormatted = !empty($entry['invoice_number']) ? str_pad(ltrim($entry['invoice_number'], '0'), 8, '0', STR_PAD_LEFT) : '00000000';
    $transactionFormatted = number_format((float)($entry['transaction_number'] ?? 0), 0);
    $rawTrx = preg_replace('/[^\d]/', '', (string)$entry['transaction_number']);

    $divDouble = str_repeat('=', $W);
    $divDash   = str_repeat('-', $W);

    $lines = [];
    $lines[] = $divDouble;

    $memberNo = trim($entry['member_number'] ?? '');
    $lines[] = 'Member #:      ' . ($memberNo !== '' ? $memberNo : '              ');

    $custName = trim($entry['customer_name'] ?? '');
    $lines[] = 'Name     : ' . ($custName !== '' ? $custName : '');

    $lines[] = $divDouble;

    if (empty($decodedItems)) {
        $lines[] = '  (No Line Items)';
    } else {
        foreach ($decodedItems as $itm) {
            $skuRaw = str_pad(trim($itm['sku'] ?? ''), 9, '0', STR_PAD_LEFT);
            $sku = str_pad($skuRaw, 16, ' ', STR_PAD_RIGHT);
            $desc = trim($itm['description'] ?? '');
            $lines[] = '  ' . $sku . '   ' . $desc;

            $qty = (float)($itm['quantity'] ?? 1);
            $amt = (float)($itm['amount'] ?? 0);
            $uPrice = (float)($itm['unit_price'] ?? ($qty > 0 ? $amt / $qty : $amt));

            $uPriceStr = 'P' . number_format($uPrice, 2, '.', '');
            $amtStr    = 'P' . number_format($amt, 2, '.', '') . 'V';

            $line2 = str_pad($uPriceStr, 16, ' ', STR_PAD_LEFT) . 
                     str_pad(number_format($qty, 0), 6, ' ', STR_PAD_LEFT) . 
                     str_pad($amtStr, 20, ' ', STR_PAD_LEFT);
            $lines[] = $line2;
        }
    }

    $lines[] = str_pad('Sub Total', 28, ' ', STR_PAD_LEFT) . str_pad('P' . number_format($subtotal, 2, '.', ''), 20, ' ', STR_PAD_LEFT);
    $lines[] = str_pad('Tax', 22, ' ', STR_PAD_LEFT) . str_pad('P0.00', 26, ' ', STR_PAD_LEFT);
    $lines[] = '';

    $lines[] = str_pad('Total', 24, ' ', STR_PAD_LEFT) . str_pad('P' . number_format($totalAmount, 2, '.', ''), 24, ' ', STR_PAD_LEFT);

    if (empty($decodedTenders)) {
        $lines[] = str_pad('Cash', 23, ' ', STR_PAD_LEFT) . str_pad('P' . number_format($totalAmount, 2, '.', ''), 25, ' ', STR_PAD_LEFT);
    } else {
        foreach ($decodedTenders as $t) {
            $tName = trim($t['name'] ?? 'Cash');
            $tName = $tenderNameMap[strtolower($tName)] ?? $tName;
            $tAmt = (float)($t['amount'] ?? 0);
            $lines[] = str_pad($tName, 23, ' ', STR_PAD_LEFT) . str_pad('P' . number_format($tAmt, 2, '.', ''), 25, ' ', STR_PAD_LEFT);
        }
    }

    $changeFormatted = 'P-' . number_format(abs($change), 2, '.', '');
    $lines[] = str_pad('CHANGE', 25, ' ', STR_PAD_LEFT) . str_pad($changeFormatted, 18, ' ', STR_PAD_LEFT);

    $vatRateStr = number_format($vatRate, 4, '.', '');
    $vatAmtStr = 'P' . number_format($totalVat, 2, '.', '');
    $lines[] = '     BIR    VAT   @ ' . $vatRateStr . str_pad($vatAmtStr, 20, ' ', STR_PAD_LEFT);

    $salesAssoc = trim($entry['sales_associate'] ?? '');
    $assocId    = trim($entry['associate_id'] ?? '');
    $lines[] = 'Sales Associate:' . $salesAssoc;
    $lines[] = 'Associate Id:    ' . $assocId;

    $storeCode = trim($entry['store_code'] ?? '');
    $regNo     = trim($entry['register_number'] ?? '');
    $tillNo    = trim($entry['till_number'] ?? '0000');
    $trxSummary = "Trx {$rawTrx} S{$storeCode} Reg{$regNo}/{$tillNo} {$trxDateStr}{$timeFormatted}";
    $lines[] = $trxSummary;

    $lines[] = 'Invoice#:' . $invoiceFormatted;

    $lines[] = $divDash;
    $lines[] = 'VATable Sales:' . str_pad('P' . number_format($vatableSales, 2, '.', ''), 22, ' ', STR_PAD_LEFT);
    $lines[] = 'VAT:          ' . str_pad('P' . number_format($totalVat, 2, '.', ''), 22, ' ', STR_PAD_LEFT);
    $lines[] = 'Non-VATable Sales:' . str_pad('P' . number_format($totalNonVat, 2, '.', ''), 18, ' ', STR_PAD_LEFT);

    return [
        'headerDate' => $headerDate,
        'trxFormatted' => $transactionFormatted,
        'lines' => $lines
    ];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Batch Print - <?php echo count($entries); ?> EJ Entries (Letter Copy)</title>
<link rel="stylesheet" href="style.css">
<style>
  @page {
      size: letter portrait;
      margin: 12mm 15mm;
  }
  * {
      box-sizing: border-box;
  }
  body {
      font-family: Arial, Helvetica, sans-serif;
      color: #000000;
      background: #f1f5f9;
      margin: 0;
      padding: 0;
  }
  .controls-bar {
      position: sticky;
      top: 0;
      background: #0f172a;
      color: #ffffff;
      padding: 12px 24px;
      display: flex;
      gap: 14px;
      align-items: center;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
      z-index: 1000;
  }
  .controls-bar a, .controls-bar button {
      background: #0284c7;
      color: #ffffff;
      border: none;
      padding: 8px 18px;
      border-radius: 5px;
      font-weight: 600;
      cursor: pointer;
      text-decoration: none;
      font-size: 13px;
      display: inline-flex;
      align-items: center;
      gap: 6px;
      transition: background 0.15s ease;
  }
  .controls-bar a:hover, .controls-bar button:hover {
      background: #0369a1;
  }
  .controls-bar button.btn-print {
      background: #16a34a;
      font-size: 14px;
      padding: 9px 22px;
  }
  .controls-bar button.btn-print:hover {
      background: #15803d;
  }
  .controls-bar a.btn-back {
      background: #475569;
  }
  .controls-bar a.btn-back:hover {
      background: #334155;
  }

  .page-viewport {
      padding: 30px 15px 80px 15px;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 30px;
  }
  .paper-info-badge {
      font-family: system-ui, -apple-system, sans-serif;
      font-size: 12px;
      font-weight: 600;
      color: #64748b;
      background: #e2e8f0;
      padding: 4px 12px;
      border-radius: 12px;
  }
  .letter-sheet {
      width: 210mm;
      min-height: 297mm;
      background: #ffffff;
      border: 1px solid #cbd5e1;
      border-radius: 2px;
      box-shadow: 0 10px 35px rgba(0,0,0,0.14);
      padding: 0.30in;
      position: relative;
      box-sizing: border-box;
      page-break-after: always;
      break-after: page;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
  }

  /* Printable area outline (Visible Margin Guide) */
  .margin-guide {
      position: absolute;
      top: <?php echo $sheetMargin; ?>in;
      left: <?php echo $sheetMargin; ?>in;
      right: <?php echo $sheetMargin; ?>in;
      bottom: <?php echo $sheetMargin; ?>in;
      border: 1px dashed #cbd5e1;
      pointer-events: none;
      z-index: 0;
  }
  .margin-guide::before {
      content: '<?php echo $sheetMargin; ?>in Margin';
      position: absolute;
      top: -16px;
      left: 0;
      font-family: system-ui, sans-serif;
      font-size: 10px;
      color: #94a3b8;
  }

  /* Left-aligned & Full-width Receipt Block */
  .receipt-container {
      width: 100%;
      max-width: 100%;
      margin: 0;
      position: relative;
      z-index: 1;
  }

  .ej-header-title {
      text-align: center;
      font-size: <?php echo $topTitleFontSize; ?>px;
      font-weight: 800;
      margin-top: <?php echo $topTitleMarginTop; ?>px;
      margin-bottom: 16px;
      color: #000000;
      letter-spacing: 0.5px;
  }
  .ej-footer-title {
      text-align: center;
      font-size: <?php echo $topTitleFontSize; ?>px;
      font-weight: 800;
      margin-top: auto;
      margin-bottom: 0;
      padding-top: 16px;
      color: #000000;
      letter-spacing: 0.5px;
      position: relative;
      z-index: 1;
      width: 100%;
  }
  .ej-meta-bar {
      display: flex;
      justify-content: center;
      align-items: center;
      gap: <?php echo $metaGap; ?>px;
      font-size: <?php echo $metaFontSize; ?>px;
      font-weight: 700;
      color: #000000;
      padding-bottom: 6px;
      border-bottom: 1.5px solid #000000;
      width: 100%;
  }
  .ej-meta-bar .meta-item span.label {
      font-weight: 800;
  }
  .ej-meta-bar .meta-item span.val {
      font-weight: 700;
  }

  .receipt-body-wrapper {
      position: relative;
      margin-top: 10px;
      padding-bottom: 8px;
      border-bottom: 1.5px solid #000000;
      width: 100%;
      min-height: 420px;
  }
  
  .watermark {
      position: absolute;
      top: <?php echo $wmTop; ?>%;
      left: <?php echo $wmLeft; ?>%;
      transform: translate(-50%, -50%) rotate(-90deg);
      transform-origin: center center;
      font-family: Arial, Helvetica, sans-serif;
      font-size: <?php echo $wmFontSize; ?>px;
      font-weight: 300;
      color: rgba(6, 182, 212, <?php echo $wmOpacity; ?>);
      white-space: nowrap;
      pointer-events: none;
      z-index: 1;
      letter-spacing: <?php echo $wmLetterSpacing; ?>px;
      user-select: none;
  }

  pre.receipt-content {
      position: relative;
      z-index: 2;
      font-family: 'Courier New', Courier, 'Lucida Console', monospace;
      font-size: <?php echo $fontSize; ?>px;
      font-weight: 400;
      line-height: <?php echo $lineHeight; ?>;
      color: #000000;
      margin: 0;
      padding: <?php echo $receiptPaddingY; ?>px <?php echo $receiptPaddingX; ?>px;
      white-space: pre;
  }

  @media print {
      @page {
          size: <?php echo $paperSize === 'letter' ? 'letter portrait' : 'A4 portrait'; ?>;
          margin: 0;
      }
      html, body {
          background: #ffffff !important;
          margin: 0 !important;
          padding: 0 !important;
          width: 100% !important;
          color: #000000 !important;
          -webkit-print-color-adjust: exact !important;
          print-color-adjust: exact !important;
      }
      .controls-bar, .paper-info-badge, .margin-guide, .margin-guide::before, .margin-guide::after {
          display: none !important;
          visibility: hidden !important;
          content: none !important;
          border: none !important;
          height: 0 !important;
          width: 0 !important;
      }
      .page-viewport {
          padding: 0 !important;
          margin: 0 !important;
          display: block !important;
          gap: 0 !important;
      }
      .letter-sheet {
          width: <?php echo $paperSize === 'letter' ? '8.5in' : '210mm'; ?> !important;
          min-height: <?php echo $paperSize === 'letter' ? '11in' : '297mm'; ?> !important;
          height: <?php echo $paperSize === 'letter' ? '11in' : '297mm'; ?> !important;
          max-width: 100% !important;
          padding: <?php echo $sheetMargin; ?>in !important;
          margin: 0 !important;
          border: none !important;
          box-shadow: none !important;
          border-radius: 0 !important;
          page-break-after: always !important;
          break-after: page !important;
          display: flex !important;
          flex-direction: column !important;
          justify-content: space-between !important;
          box-sizing: border-box !important;
      }
      .receipt-container {
          width: 100% !important;
          max-width: 100% !important;
          margin: 0 !important;
      }
      .watermark {
          color: rgba(6, 182, 212, <?php echo $wmOpacity; ?>) !important;
          -webkit-print-color-adjust: exact !important;
          print-color-adjust: exact !important;
      }
      pre.receipt-content {
          font-size: <?php echo ($fontSize * 0.77); ?>pt !important;
          line-height: <?php echo $lineHeight; ?> !important;
          padding: <?php echo $receiptPaddingY; ?>px <?php echo $receiptPaddingX; ?>px !important;
          margin: 0 !important;
      }
      .ej-footer-title {
          margin-top: auto !important;
          margin-bottom: 0 !important;
          padding-bottom: 0 !important;
      }
  }
</style>
</head>
<body>

<div class="controls-bar">
    <button class="btn-print" onclick="window.print()">🖨️ Print All (<?php echo count($entries); ?> Entries - <?php echo strtoupper($paperSize); ?>)</button>
    <a class="btn-back" href="ej_printing.php">← Back to EJ Records</a>
    <span style="font-size: 13px; color: #94a3b8; font-weight: 500;"><?php echo count($entries); ?> entries selected</span>
    <button type="button" onclick="document.querySelectorAll('.margin-guide').forEach(el => el.style.display = el.style.display === 'none' ? 'block' : 'none')" style="background: #334155; font-size: 12px; margin-left: auto;">📐 Toggle Margin Guides</button>
</div>

<div class="page-viewport">
    <div class="paper-info-badge">📄 <?php echo $paperSize === 'letter' ? 'US Letter: 8.5" × 11.0"' : 'A4 Paper: 210mm × 297mm'; ?> | Margins: <?php echo number_format($sheetMargin, 2); ?>" All Sides</div>

    <?php foreach ($entries as $e): ?>
        <?php $rendered = formatSingleEjReceipt($e, $tenderNameMap, $W); ?>
        <div class="letter-sheet">
            <div class="margin-guide"></div>
            
            <!-- Top Receipt Container -->
            <div class="receipt-container">
                <!-- Top Title -->
                <div class="ej-header-title">*** Electronic Journal Copy ***</div>

                <!-- Meta Bar -->
                <div class="ej-meta-bar">
                    <div class="meta-item"><span class="label">Date:</span> <span class="val"><?php echo htmlspecialchars($rendered['headerDate']); ?></span></div>
                    <div class="meta-item"><span class="label">Store:</span> <span class="val"><?php echo htmlspecialchars($e['store_code']); ?></span></div>
                    <div class="meta-item"><span class="label">Register:</span> <span class="val"><?php echo htmlspecialchars($e['register_number']); ?></span></div>
                    <div class="meta-item"><span class="label">Transaction:</span> <span class="val"><?php echo htmlspecialchars($rendered['trxFormatted']); ?></span></div>
                </div>

                <!-- Receipt Area with Centered Vertical Watermark -->
                <div class="receipt-body-wrapper">
                    <div class="watermark"><?php echo htmlspecialchars($wmText); ?></div>
                    <pre class="receipt-content"><?php echo htmlspecialchars(implode("\n", $rendered['lines'])); ?></pre>
                </div>
            </div>

            <!-- Bottom Pinned Title -->
            <div class="ej-footer-title">*** Electronic Journal Copy ***</div>
        </div>
    <?php endforeach; ?>
</div>

</body>
</html>
